#!/bin/sh
# Build the inference-runtime report: charts from the result files, then the PDF.
# Run from anywhere inside `nix develop .#runtimes` (which provides typst).
set -eu
here=$(cd "$(dirname "$0")" && pwd)
root=$(cd "$here/../../.." && pwd)
res="$root/spikes/runtimes/results"
set -- --out "$here/charts" --gpu "$res/mac-m3pro-gpu.json" \
  --machine "Mac M3 Pro=$res/mac-m3pro.json"
[ -f "$res/linux-x86_64.json" ] && set -- "$@" --machine "Linux x86-64 (GitHub runner)=$res/linux-x86_64.json"
[ -f "$res/linux-arm64.json" ] && set -- "$@" --machine "Linux ARM64 (GitHub runner)=$res/linux-arm64.json"
python3 "$root/spikes/runtimes/charts.py" "$@"
typst compile --root "$root" "$here/report.typ" "$here/report.pdf"
echo "wrote $here/report.pdf"
