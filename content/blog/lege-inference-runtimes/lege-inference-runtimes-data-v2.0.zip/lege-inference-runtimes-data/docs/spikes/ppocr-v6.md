# PP-OCRv6: the runtime comparison repeated, and the v6 detector with the v5 recognizer

Run 2026-11-08 and 09 on branch `spike/v6`. Memory figures are in GiB (2^30
bytes); the first version of this note labelled them GB. Accuracy with the
corrected detector settings is in `docs/spikes/review-fixes.md`. This repeats the comparison in
`docs/spikes/runtimes.md` (tract, RTen and ONNX Runtime). It uses PaddleOCR's
PP-OCRv6 models, released 2026-06-11 in PaddleOCR 3.7.0, in place of the
PP-OCRv5 models Lege ships. The rule in `docs/spikes/runtimes-decision-rule.md`
is applied unchanged. Where Lege still assumes PP-OCRv5 is covered separately in
`docs/spikes/ppocr-v5-hardcoding.md`.

## Short answer

- **Model: stay on PP-OCRv5.**
  - v6 is not more accurate on Lege's Latin-script pages.
  - The v6 detector paired with the v5 recognizer reads about as well as v5,
    at about the same speed. So switching would cost a new ADR and 25
    re-approved snapshots and gain nothing measurable.
  - v6 has no Latin-only recognizer. Its dictionaries are 85–89% Chinese
    characters.
- **Library: the v5 choice still stands, but its safety margin is thinner than
  it looked.**
  - With v5, Microsoft's official ONNX Runtime build gave the same output at
    every thread count on every machine.
  - With v6 models, the official build changed its output with the
    thread count on Linux ARM64 and the Mac for three model sets: v6 tiny,
    v6 small, and v6 tiny detector + v5 recognizer.
  - This means ONNX Runtime's thread-count consistency depends on the model.
    Passing with v5 does not guarantee it will keep passing.
  - RTen and tract gave the same output at every thread count in every run.
- **Sizes:**
  - v6 tiny is about twice as fast as v5 but reads worse. Its detector garbles
    a clean synthetic line no matter which thresholds are used.
  - v6 medium is 3–7 times slower than v5 on one thread. With tract it peaks at
    4.63 GiB, more than twice the 2 GB limit.

## What was run

| Set | Detector | Classifier | Recognizer and dictionary |
|---|---|---|---|
| v5 (approved) | PP-OCRv5 mobile | PP-LCNet_x0_25_textline_ori | latin_PP-OCRv5_mobile_rec, 836 entries |
| v6 tiny / small / medium | PP-OCRv6 of that size | the same v5 classifier (v6 has none) | PP-OCRv6 of that size; 6,904 entries (tiny) or 18,708 (small, medium) |
| hybrid tiny / small / medium | PP-OCRv6 of that size | the same v5 classifier | the v5 Latin recognizer and dictionary |

- **Model files:** the official ONNX exports on Hugging Face, pinned by
  revision and SHA-256 in `spikes/runtimes/fetch-v6-models.sh`.
- **Dictionaries:** v6 ships its dictionary inside `inference.yml`.
  `spikes/runtimes/v6_dict.py` extracts it, and the result was checked to be
  byte-identical to PyYAML's parse.
- **Detector thresholds:** every v6 detector, including in the hybrids, ran with
  0.2 pixel, 0.4 box, unclip 1.4, set through the spike-only variable
  `LEGE_SPIKE_DET`, and Lege's limit of 1,000 candidate boxes. v5 uses 0.3, 0.6
  and 1.5. **Correction (2026-11-12):** PP-OCRv6's published pipeline settings
  use box 0.4 only for tiny; small and medium use 0.45, and all sizes allow
  3,000 candidates. The speed, memory and thread-count runs here were not
  repeated (the change alters the work done only slightly). The accuracy runs
  were repeated with the published settings, plus a threshold sweep, on branch
  `spike/review`; see `docs/spikes/review-fixes.md` and version 2.0 of the
  report.
- **Code:** Lege's code was otherwise unchanged. Its check that the
  recognizer's output width equals the dictionary size plus 2 passed for every
  set.
- **Where it ran:**
  - Mac M3 Pro, locally.
  - GitHub runs 42551939160 and 42560011661, on the Linux x86-64 and ARM64
    runners and under emulated Nehalem and SandyBridge CPUs.
  - Medium was cancelled on Linux to save cost, so it was measured on the Mac
    only.

## Speed and memory

Totals are for the 25 reference images, median of 3 runs after a warm-up. The
GitHub runners have 2 cores, so "N thr" is 2 on Linux and 4 on the Mac.

**Linux x86-64.** The runner's CPU varies from job to job, so only rows on the
same CPU compare directly with v5. Those rows are v6 small and hybrid small,
which ran on the AMD EPYC 7763.

| Models | CPU | tract 1 / 2 thr | RTen 1 / 2 thr | ONNX Runtime 1 / 2 thr | Peak memory (tract / RTen / ORT) |
|---|---|---|---|---|---|
| v5 (approved) | AMD EPYC 7763 | 123.3 / 121.7 s | 110.5 / 110.7 s | 64.5 / 64.7 s | 0.38 / 0.41 / 0.53 GiB |
| v6 tiny | AMD EPYC 9V74 | 59.9 / 54.2 s | 42.4 / 38.4 s | 23.6 / 23.2 s | 0.28 / 0.31 / 0.35 GiB |
| v6 small | AMD EPYC 7763 | 149.2 / 138.1 s | 117.8 / 111.9 s | 77.7 / 75.4 s | 0.73 / 0.46 / 0.55 GiB |
| hybrid tiny | Intel Xeon 6975P-C | 82.2 / 79.5 s | 89.5 / 85.9 s | 50.6 / 50.7 s | 0.44 / 0.33 / 0.36 GiB |
| hybrid small | AMD EPYC 7763 | 140.0 / 129.7 s | 121.8 / 119.9 s | 68.2 / 67.3 s | 0.36 / 0.43 / 0.50 GiB |

**Linux ARM64:**

| Models | tract 1 / 2 thr | RTen 1 / 2 thr | ONNX Runtime 1 / 2 thr | Peak memory (tract / RTen / ORT) |
|---|---|---|---|---|
| v5 (approved) | 133.2 / 90.2 s | 111.0 / 66.9 s | 94.8 / 55.7 s | 0.38 / 0.41 / 0.53 GiB |
| v6 tiny | 61.9 / 42.8 s | 47.5 / 28.8 s | 43.2 / 26.7 s | 0.26 / 0.31 / 0.35 GiB |
| v6 small | 183.5 / 110.8 s | 148.6 / 82.2 s | 137.2 / 76.4 s | 0.71 / 0.46 / 0.55 GiB |
| hybrid tiny | 130.8 / 88.2 s | 106.9 / 64.2 s | 92.3 / 54.0 s | 0.44 / 0.33 / 0.35 GiB |
| hybrid small | 151.7 / 96.9 s | 123.5 / 71.9 s | 106.1 / 60.2 s | 0.35 / 0.44 / 0.50 GiB |

**Mac M3 Pro:**

| Models | tract 1 / 4 thr | RTen 1 / 4 thr | ONNX Runtime 1 / 4 thr | Peak memory (tract / RTen / ORT) |
|---|---|---|---|---|
| v5 (approved) | 47.5 / 35.4 s | 53.7 / 21.7 s | 50.8 / 20.5 s | 1.06 / 0.46 / 0.58 GiB |
| v6 tiny | 26.9 / 18.6 s | 23.1 / 10.3 s | 22.1 / 10.7 s | 0.71 / 0.35 / 0.42 GiB |
| v6 small | 63.6 / 36.2 s | 70.8 / 24.4 s | 68.2 / 24.5 s | 1.48 / 0.56 / 0.69 GiB |
| v6 medium | 171.8 / 86.1 s | 340.8 / 94.3 s | 330.7 / 91.0 s | **4.63** / 1.47 / 1.62 GiB |
| hybrid tiny | 46.5 / 32.0 s | 52.7 / 20.7 s | 49.2 / 19.2 s | 1.04 / 0.36 / 0.42 GiB |
| hybrid small | 53.7 / 32.8 s | 59.3 / 22.1 s | 54.8 / 20.2 s | 1.15 / 0.50 / 0.56 GiB |
| hybrid medium | 113.3 / 57.0 s | 155.7 / 48.7 s | 140.8 / 43.8 s | **2.50** / 1.27 / 1.39 GiB |

What the tables show:

- **The recognizer sets the speed.** Swapping in a v6 detector of any size
  barely changes the time. The hybrids run within about 10% of v5. The v6 tiny
  recognizer is the only part that is much faster than v5's.
- **The library order is the same as with v5.** ONNX Runtime is fastest on one
  Linux x86-64 thread by 35–45%. RTen and ONNX Runtime are level at 4 threads on
  the Mac. tract trails both whenever it has more than one thread, as before
  (sonos/tract#2899).
- **Medium breaks the memory limit with tract.** It peaks at 4.63 GiB with v6
  medium and 2.50 GiB with the hybrid medium. RTen and ONNX Runtime stay under
  2 GB with both.

## Same output at any thread count

Each check compares the ALTO bytes of all 25 images at 1, 2, 3, 4, 6 and 8
threads with the 1-thread run.

| Models | Machine | tract | RTen | ONNX Runtime (Nix build) | ONNX Runtime (official build) |
|---|---|---|---|---|---|
| v6 tiny | Linux x86-64 | same | same | same | same |
| v6 tiny | Linux ARM64 | same | same | same | same |
| v6 tiny | Mac | same | same | 3 images differ | **1 image differs at 4–8 thr** |
| v6 small | Linux x86-64 | same | same | same | same |
| v6 small | Linux ARM64 | same | same | 2 images differ at 8 thr | **1 image differs at 2–8 thr** |
| v6 small | Mac | same | same | 4 images differ | same |
| v6 medium | Linux x86-64 | not run | not run | not run | same |
| v6 medium | Linux ARM64 | not run | not run | not run | same |
| v6 medium | Mac | same | same | same | not run |
| hybrid tiny | Linux x86-64 | same | same | same | same |
| hybrid tiny | Linux ARM64 | same | same | same | **1 image differs at 8 thr** |
| hybrid tiny | Mac | same | same | 1 image differs | same |
| hybrid small | Linux x86-64 | same | same | same | same |
| hybrid small | Linux ARM64 | same | same | same | same |
| hybrid small | Mac | same | same | 1 image differs | same |
| hybrid medium | Mac | same | same | 1 image differs | not run |

The images that differed:

- **Official build:**
  - v6 small on ARM64: `pd-stevenson-treasure-1907-n120`.
  - Hybrid tiny on ARM64: `pd-aurelius-meditations-1887-n100-rot180`.
  - v6 tiny on the Mac: `pd-aurelius-meditations-1887-n100-rot180`.
- **Nix build, Mac:**
  - v6 tiny: `pd-aurelius-meditations-1887-n100-rot180` and both
    `pd-kafka-heizer-1913-n20` images.
  - v6 small: `pd-stevenson-treasure-1907-n120`, `pd-mickiewicz-pisma-1877-n120`
    and both `pd-walden-1893-n150-flip` images.
  - Hybrid tiny: `pd-aurelius-meditations-1887-n100-rot180`.
  - Hybrid small and hybrid medium: `pd-austen-pride-1894-n120`.
- **Nix build, ARM64:** v6 small: both `pd-walden-1893-n150-flip` images.

On the Mac, the three libraries also gave the same text as each other for all
25 images, at 1 and 4 threads, for every v6 and hybrid set. On Linux, their mean
character error rates on the 5 scored pages were identical in every run.

## Old CPUs

Every v6 run finished without failures under emulation, with all three
libraries:

- Nehalem (no AVX): tiny and small.
- SandyBridge (AVX, no AVX2): tiny and small.

The run checks 3 images and scores 1 page. The tiny models misread that page:
the clean synthetic line at 0.149 character error rate, the same as on native
hardware. Small read it exactly.

## Accuracy

Character error rate against the transcriptions in `tests/fixtures/reference`,
from `spikes/runtimes/v6_accuracy.py`. The v5 column is the approved snapshot.

There are two kinds of transcription:

- **Ground truth:** 4 synthetic lines, exact by construction.
- **Drafts:** 12 scanned pages. They are not yet reviewed, and were made by
  checking v5's output against the book, which favours v5.

One draft, `pd-goodytwoshoes-1888-n8`, is 31 characters long, and a single
misread word there moves the 12-page average by several times the whole
difference between models. So the drafts are also shown without it.

| Models | Ground truth (4) | Drafts (12) | Drafts without the short page (11) | Pages worse / better than v5 (of 11) |
|---|---|---|---|---|
| v5 (approved) | 0.0020 | 0.0413 | 0.0026 | — |
| v6 tiny | 0.0434 | 0.0414 | 0.0118 | 10 / 1 |
| v6 small | 0.0030 | 0.0095 | 0.0043 | 6 / 2 |
| v6 medium | 0.0040 | 0.0115 | 0.0035 | 6 / 2 |
| hybrid tiny | 0.0371 | 0.0329 | 0.0025 | 5 / 3 |
| hybrid small | 0.0020 | 0.0130 | 0.0021 | 4 / 4 |
| hybrid medium | 0.0020 | 0.0135 | 0.0026 | 6 / 2 |

- **v6 small and medium read slightly worse than v5.** They do better only on
  the 31-character page. The drafts' bias toward v5 may account for some of
  the gap, but none of it points to v6 being better.
- **The hybrid small reads as well as v5.** Its output differs from the
  snapshot on 18 of 25 images, so adopting it would still mean re-approving
  the snapshots, for no measured gain.
- **The v6 tiny detector garbles `syn-clean-001`** (0.14–0.15 error with either
  recognizer). That makes tiny unusable as a default.

## The decision rule applied to v6

| Requirement | tract | RTen | ONNX Runtime (official build) |
|---|---|---|---|
| Same output at any thread count | passes (medium on the Mac only) | passes | **fails** for v6 tiny (Mac), v6 small (ARM64) and hybrid tiny (ARM64) |
| Runs on old CPUs | passes | passes | passes |
| Peak memory under 2 GB | fails for medium (4.63 GiB) and hybrid medium (2.50 GiB) | passes | passes |
| Same text | the three agree with each other; no v6 snapshot exists | | |

- **If Lege moved to v6 small,** the rule would rule out ONNX Runtime and pick
  RTen. RTen is 117.8 s against tract's 149.2 s on one Linux x86-64 thread, a
  21% gap.
- **For the hybrid small,** the official build passed everywhere it was run, so
  the result would be the same as with v5.
- **The model is not changing,** so this is a warning rather than a decision.
  The v5 decision assumed ONNX Runtime's consistency was a property of the
  build. These runs show it also depends on the model.

## What this means for Lege

1. **Keep PP-OCRv5.** Revisit if PaddleOCR publishes a Latin-only v6
   recognizer.
2. **Keep the thread-count check for the shipped ONNX Runtime build as a CI
   gate,** run on every model change and every ONNX Runtime upgrade on x86-64
   and ARM64. Passing once is not enough.
3. **Keep RTen as the fallback.** It passed every requirement in every run,
   with v5 and with v6.
4. Before any future model switch, fix what `ppocr-v5-hardcoding.md` lists. In
   particular, model names should be data, so that the ALTO reports the models
   actually used.

## Files

- **Results:** `spikes/runtimes/results/v6/`. It has one folder per run, each
  holding `results.json` and `results.md` from `bench.py` and `threads.json`
  from `threads_check.py`, plus `accuracy.json`.
- **Scripts:** `spikes/runtimes/fetch-v6-models.sh`, `v6_dict.py`,
  `v6_accuracy.py`, and the workflow `.github/workflows/spike-v6.yml`.
- **Spike-only code:** `LEGE_SPIKE_DET` in `crates/lege-cli/src/run.rs`. It is
  not for main.
