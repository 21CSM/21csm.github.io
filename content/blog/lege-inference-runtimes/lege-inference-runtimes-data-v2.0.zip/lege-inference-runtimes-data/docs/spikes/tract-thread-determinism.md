# Spike: tract 0.23.9 thread-count determinism

Label: **development machine only**. This is not an X220 and not Sandy Bridge. The machine reports `Intel(R) Xeon(R) Processor` with AVX, AVX2, FMA, and AVX-512 (`/proc/cpuinfo` flags include `avx`, `avx2`, `fma`, `avx512f`). Four vCPUs. tract picks kernels from CPUID, so this does not exercise the AVX-without-AVX2 tier ADR-0004 calls out for the ThinkPad X220. ADR-0004 stays proposed until that machine is run.

Date: 2026-10-29. Rustc `1.99.1` (`58cf8f9c3`, 2026-10-13), from rustup stable. tract-onnx and tract-linalg pinned `=0.23.9`, feature `multithread-mm`. No `TRACT_*` variable was set.

## Models

Fetched with `scripts/fetch-ppocr-models.sh` into `/tmp/ppocr-models` (not committed). SHA-256 of the files on disk matched ADR-0014:

| File | SHA-256 |
|---|---|
| `det.onnx` | `a431985659dc921974177a95adcfbb90fd9e51989a5e04d70d0b75f597b6e61d` |
| `cls.onnx` | `94a6a0a0425f2b5f08b5df72086f2d72abe40f1d22f6d12d2cd83674f11f2ff3` |
| `rec.onnx` | `7888113072263cb471b93f66dd5e2ad70548dc526fa1ace760d0d973dd121498` |
| `dict.txt` | `ccbcc45730b3fbbd9050c5bc74db6a99067141ef1035e3d14889a84a6b9b1aff` |

`dict.txt` is 836 lines. The dictionary is not an input to this spike; the three ONNX files are.

## Method

Harness: `spikes/tract-thread-determinism` (`cargo run -p tract-thread-determinism --release -- /tmp/ppocr-models`).

Each model is loaded once from the unmodified bytes with `tract_onnx::onnx().with_ignore_value_info(true).with_ignore_output_shapes(true).model_for_read`, the input fact pinned to one concrete shape, then `into_optimized().into_runnable()`. One plan per model. The same plan is run at 1, 1, 2, and 4 threads (`Executor::SingleThread`, then `Executor::multithread`) inside `multithread_tract_scope`. The two single-thread runs check that one thread is stable. Raw output bytes are `Tensor::as_bytes()` on this little-endian host (IEEE-754 f32, little-endian). Compared with `==`, not with `f32` equality.

Inputs are one deterministic fixture per model, not a rendered page. Values are `((i * 17) % 251) as f32 / 250.0 - 0.5`:

| Model | Shape |
|---|---|
| det | `[1, 3, 448, 960]` |
| cls | `[1, 3, 80, 160]` |
| rec | `[1, 3, 48, 320]` |

The sweep is repeated after `set_threading_panel_threshold(0)`. The element and MAC thresholds stay at tract's defaults. The library does not call `set_threading_panel_threshold`; the spike process does, and then exits.

`Display` of the optimized ops did not contain the substrings `avx`, `avx2`, `avx512`, or `fma` (det 546 nodes, cls 292, rec 493). That does not show which kernel tier ran. Det wall time fell as the thread count rose, so the multi-thread executor was doing work. These times are one run each, including cache effects, and are not a benchmark.

## Result

**Identical.** Every model, at 1 (both runs), 2, and 4 threads, produced the same bytes. Forcing the panel threshold to 0 did not change any hash relative to the default thresholds either.

| Output | SHA-256 of raw f32 bytes | Default 1 / 2 / 4 s | Panel 0: 1 / 2 / 4 s |
|---|---|---|---|
| det | `b5968068f5fda9e0af2485a0849eaaadecf9ad6c0683c47d6470090307275b3b` | 0.154, 0.131 / 0.109 / 0.080 | 0.139, 0.130 / 0.112 / 0.076 |
| cls | `0445ae5e8d46134954ff013eb13ca0d028f1938f352eb443d63ca0423e9e59e2` | 0.002, 0.002 / 0.002 / 0.002 | 0.002, 0.002 / 0.002 / 0.002 |
| rec | `2fca087a3d081ad0881e52a618eec9172f8529834933411fa4d51061a2eefc41` | 0.018, 0.018 / 0.016 / 0.011 | 0.018, 0.018 / 0.016 / 0.011 |

Single-thread output matched itself. There is no reason, on this machine, to ignore `RunOptions::threads` or to switch to ort. `lege-ppocr` keeps the contract: `None` or 1 is `Executor::SingleThread`, and any larger count is `Executor::multithread(n)`, scoped per `run`. The X220 can still disagree, because it uses different kernels. If it does, the fallback inside tract is single-thread inference, not ort.

## nixpkgs unstable and rustc 1.91

Nix is not installed in this VM. The check is the `nixos-unstable` tree at commit `31ecbaca1bdefa45dffc409f0250bd8039ea0010` (2026-10-27, "h2o: 2.3.0-rolling-2026-10-24 → 2.3.0-rolling-2026-10-27").

`pkgs/top-level/all-packages.nix` sets `rust_1_99 = callPackage ../development/compilers/rust/1_99.nix`, then `rust = rust_1_99` and `rustPackages = rust_1_99.packages.stable`, and inherits `rustc` from `rustPackages`. `pkgs/development/compilers/rust/1_99.nix` sets `rustcVersion = "1.99.0"`.

**Yes.** The default `pkgs.rustc` on nixpkgs unstable at that commit is 1.99.0, which is `>= 1.91`. tract-onnx 0.23.9's declared MSRV is 1.91. A Nix build of this workspace was not run.
