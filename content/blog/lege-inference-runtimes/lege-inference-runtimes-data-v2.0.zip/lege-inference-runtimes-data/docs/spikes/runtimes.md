# Spike: which inference library should Lege use?

Status: finished on the Mac; Linux re-run after the tract fix still to do (CI is
blocked on billing). Decision recorded in ADR-0004.

Branches: `spike/runtimes` (the three libraries, CPU) and `spike/gpu` (GPU
options, benchmark fixes and the latest results). Neither is meant to merge.

## The question

Lege runs three small neural networks on every page: one finds the text, one
checks whether each line is upside down, and one reads the line. Something has
to run those networks. ADR-0004 picked **tract**. Before accepting that, we
measured it against **RTen** and **ONNX Runtime** on the things Lege promises:

- the same output at any thread count on the same machine;
- runs on low-end computers: any 64-bit x86 or ARM CPU, CPU only, about 4 GB
  of RAM, including CPUs without AVX;
- no CPU-specific code, and no second library kept just for old machines;
- easy to build and ship.

## How it was measured

- Same Lege code three times; only the inference library differs. Everything
  around the networks (image preparation, finding boxes, reading characters
  out of the network's output) is unchanged, so this measures the real
  pipeline, not a toy.
- The real `lege` command line, one process per page, as people use it.
- All 25 reference images. Several are the same page saved as a different
  TIFF type, so there are about 17 distinct pages.
- A warm-up run, then the median of 3. The libraries take turns image by
  image, so a slowdown partway through hits all three alike.
- Output is compared with the approved snapshots and across thread counts.
- Harness: `spikes/runtimes/bench.py`. CI: `.github/workflows/spike-runtimes.yml`.

## A Lege bug the spike found

tract was slowest everywhere at first, and most of that was not tract. Lines on
a page have different widths, and Lege rebuilt the line-reading model from
scratch for every new width: about 80 ms each, nearly once per line. A page
spent more time preparing the model than reading.

Fixed on the spike branch: the slow, width-independent preparation now runs
once, and each new width only does the quick last step. Output is byte-identical
on all 25 images at every thread count.

| tract on the Mac, 25 images | Before | After |
|---|---|---|
| 1 thread | 73.3 s | 47.5 s |
| 4 threads | 60.3 s | 35.4 s |

The fix should go to main whatever we decide, because it also makes the current
release much faster. It costs about 100 MB more memory on full pages.

## Results

### Mac (M3 Pro), after the fix

| | 1 thread | 4 threads | Peak memory | Same output at any thread count |
|---|---|---|---|---|
| tract | 47.5 s | 35.4 s | 1.06 GB | yes |
| RTen | 53.7 s | 21.7 s | 0.46 GB | yes |
| ONNX Runtime | 50.8 s | 20.5 s | 0.58 GB | **no** |

Fastest and slowest runs were within 2% of the median. Full table:
`spikes/runtimes/results/mac-m3pro.md`.

### Linux on GitHub's runners, before the fix

These are from before the tract fix, so tract's times are too slow here.
GitHub gives private repos smaller runners, most likely 2 virtual cores (the job
did not print the count), so the thread-scaling results are left out.

| | x86-64, 1 thread | ARM64, 1 thread | Peak memory |
|---|---|---|---|
| tract (before fix) | 111.1 s | 179.5 s | 0.39 GB |
| RTen | 66.1 s | 112.4 s | 0.42 GB |
| ONNX Runtime | 35.2 s | 95.7 s | 0.53 GB |

### Reading the text

Every library, on every machine, read the same text as the snapshots on all 25
images. The only differences are tiny changes in confidence scores in the ALTO
file. On the machine the snapshots were made on, tract matched every ALTO file
byte for byte; RTen differed on 2 and ONNX Runtime on 1. Switching away from
tract therefore means re-approving a few snapshots, nothing more.

### Same output at any thread count

All 25 images were run at 1, 2, 3, 4, 6 and 8 threads on the Mac.

- tract and RTen: identical every time.
- ONNX Runtime: identical except at exactly 4 threads, on one image
  (`pd-aurelius-meditations-1887-n100-rot180`), every time. Its "deterministic
  compute" setting does not fix it. Which thread count misbehaves depends on
  the machine, so we could not promise this requirement without running it on
  one thread.

### Old CPUs

Checked by running the x86 builds under QEMU with an older CPU model. Speeds
under emulation are not real, only the correctness is.

- **No AVX at all (Nehalem class):** all three ran every image, the text
  matched, and output did not change with the thread count.
- **AVX without AVX2 (SandyBridge, ThinkPad X220 class):** not finished. The
  first attempt hit GitHub's 5-hour limit, and the shorter re-run was refused
  for billing.

### GPU (Mac only)

tract's Metal backend and ONNX Runtime with Apple's Core ML both work and read
exactly the same text. Neither is worth it: on a fresh page, every GPU option
(1.8 s or slower) is about twice as slow as RTen or ONNX Runtime on 4 CPU
threads (0.8–0.9 s). The models are small and Lege reads one line at a time,
so moving data to the GPU and back costs about as much as the work. Reading
many lines at once could change that, but it pads lines and changes the
output, so it could only ever be an opt-in setting. NVIDIA was not tested.

### Building and shipping

| | Extra crates | Ships with Lege | Notes |
|---|---|---|---|
| tract | (current) | nothing | pure Rust |
| RTen | 11 | nothing | pure Rust, loads `.onnx` files directly |
| ONNX Runtime | 3 | a 28 MB C++ library, plus protobuf and libiconv | 136 MB in Nix; has to be found at run time |

The Lege binary is about 40 MB with any of them, because the spike builds still
link tract for checking model files. A real switch would drop that.

## Mistakes in the first round, and fixes

An adversarial review of the benchmark found these, all now fixed or measured:

- Each library ran as one block. RTen's 1-thread time fell from 74.0 s to
  53.7 s once the libraries took turns.
- A "warm" GPU test reread the same page, so tract had every line width ready.
  On a different page tract takes 2.06 s, not 1.41 s.
- The GPU was compared with 1 CPU thread instead of the CPU at its best.
- ONNX Runtime had thread spinning off, costing it about 12% at 4 threads.
- Only the median was shown; the spread and the character error rate are now
  in the table.

## Recommendation

**RTen.** It is the only option that meets every requirement and is also fast:

- the same output at any thread count, like tract;
- about as fast as ONNX Runtime with threads, and much faster than tract;
- the lowest memory, which matters most on a 4 GB machine;
- pure Rust, nothing extra to ship, and it runs on CPUs without AVX.

Against it:

- it is younger than tract (version 0.27) and mostly one maintainer's work;
- 2 ALTO snapshots need re-approving;
- it was slowest on one thread on the Mac, by about 13%.

ONNX Runtime is out because of the thread-count problem and the shipping cost.
tract stays a reasonable fallback, since Lege keeps the inference library behind
one small module.

## Still to do

- Re-run Linux x86-64 and ARM64 after the fix, and finish the SandyBridge
  check, once GitHub billing is sorted.
- Look into tract's extra 100 MB after the fix (only matters if we keep tract).
- NVIDIA: untested, and not needed for v0.1.
