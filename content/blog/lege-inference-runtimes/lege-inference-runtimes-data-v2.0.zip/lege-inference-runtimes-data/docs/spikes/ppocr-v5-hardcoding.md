# Where Lege assumes PP-OCRv5

Checked 2026-11-08 on branch `spike/v6`, while testing PP-OCRv6. Search:
`git grep -iE "pp-?ocr_?v?5|ppocrv5"` plus a read of every model-specific constant
in `crates/lege-ppocr`.

**Short answer:** the code that runs the networks is not tied to PP-OCRv5. It
loaded and ran PP-OCRv6 tiny, small and medium unchanged. Two things in the
binary are tied to v5, and everything else is tests, snapshots and documents
that name the v5 files.

## In the binary

| Where | What | Effect with other models |
|---|---|---|
| `crates/lege-cli/src/args.rs:49-56` (`Role::model_name`) | The model names `PP-OCRv5_mobile_det`, `PP-LCNet_x0_25_textline_ori`, `latin_PP-OCRv5_mobile_rec`, `ppocrv5_latin_dict` are fixed per role. | Any model in `--models` is reported under these names, in every ALTO file's metadata and in error messages. With PP-OCRv6 the ALTO says PP-OCRv5. **The output would mislabel its own provenance.** The SHA-256 next to each name is computed from the real file, so it stays correct. |
| `crates/lege-ppocr/src/settings.rs` (`DetectionSettings::default`) | Detector thresholds 0.3 (pixel), 0.6 (box) and unclip ratio 1.5, documented as "the PP-OCR reference". | These are PP-OCRv5's values. PP-OCRv6 ships 0.2, 0.4 and 1.4. There is no command-line option to change them; the spike added the env var `LEGE_SPIKE_DET` to test v6 with its own values. |

Not tied to v5, checked against PP-OCRv6's `inference.yml`:

- detector normalisation (ImageNet mean and standard deviation) and the
  resize rules: same in v6;
- recognizer input height 48 and normalisation `(x/255 - 0.5)/0.5`: same in v6;
- CTC decoding with a blank class and a trailing space class; Lege checks that
  the model's output width is the dictionary size plus 2, so a mismatched
  dictionary fails loudly rather than misreading;
- `crates/lege-ppocr/src/runtime.rs:85` mentions the v5 detector export in a
  comment only; the check it describes accepts any export.

## Outside the binary

| Where | What |
|---|---|
| `scripts/fetch-ppocr-models.sh` | Download URLs and SHA-256 pins for the v5 files. |
| `tests/acceptance/cli_contract.toml`, `tests/acceptance-rs/tests/ppocr_api_acceptance.rs`, `crates/lege-ppocr/tests/real_models.rs`, `crates/lege-alto/tests/write_alto.rs` | v5 names and SHA-256 pins. |
| `crates/lege-cli/src/tests.rs`, `crates/lege-ppocr/src/engine.rs` and `error.rs` (unit tests), `crates/lege-core/src/settings.rs` (unit test) | v5 names in assertions. |
| `tests/fixtures/test-engine/**`, `tests/tools/gen_test_engine_fixtures.py` | v5 names and pins in fixture inputs and expected outputs. |
| `tests/fixtures/reference/expected/*.alto.xml` (25 files) | Approved snapshots. They name the v5 files and, more to the point, hold v5's output; any model change means re-approving all 25. |
| `specs/v0.1/contracts/cli.md`, `traits.md`, `research.md`, `plan.md`; `docs/adr/0004`, `docs/adr/0014` | The v0.1 specification and decisions name the v5 files. ADR-0014 chose the Latin v5 recognizer and its dictionary. |

## What a model switch would need

1. Make the model names data, not code: read them from a small manifest next
   to the models (or a pinned table per model set) so the ALTO names the files
   actually used.
2. Make the detector thresholds part of the model set, with the values
   recorded in the ALTO settings as they are now.
3. A new ADR superseding the model choice in ADR-0014, new pins, and
   re-approved snapshots.
