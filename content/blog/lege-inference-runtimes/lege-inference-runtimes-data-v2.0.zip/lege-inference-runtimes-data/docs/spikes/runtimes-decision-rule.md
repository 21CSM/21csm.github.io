# How the inference library will be chosen

Written on 2026-11-08, after the Mac results and before the second Linux and
emulation run (GitHub Actions run 42524218141) reported anything. The rule is
fixed here so the new data cannot be read to fit a favourite.

## 1. Requirements: failing any one rules a library out

1. **Same output at any thread count.** The ALTO file is byte-identical at 1, 2,
   3, 4, 6 and 8 threads, for all 25 reference images, on every machine tested:
   Mac M3 Pro, Linux x86-64 and Linux ARM64.
2. **Runs on old CPUs.** On the emulated Nehalem (no AVX) and SandyBridge (AVX,
   no AVX2) CPUs, every page runs and the text matches the snapshot.
3. **Fits a 4 GB machine.** Peak memory stays under 2 GB on every page, on every
   machine, leaving room for the operating system.
4. **Same text.** The text matches the approved snapshot on every page and
   machine.

ONNX Runtime is judged by the build Lege would ship. If the Nix build fails
requirement 1 but Microsoft's official build passes it everywhere, ONNX Runtime
stays in, on the condition that Lege ships the official build.

## 2. Ranking: among the libraries that pass

1. **Speed on one thread on Linux x86-64.** Low-end machines have few cores, so
   this is the closest stand-in for Lege's target users. Totals within 10% of
   each other count as a tie.
2. **Speed at 4 threads on the Mac**, for machines with more cores. Again,
   within 10% is a tie.
3. **Ties are broken by**, in order: nothing extra to ship with Lege, then lower
   peak memory, then fewer added crates.

## 3. What would reopen the decision

- A requirement failure found later on real low-end hardware.
- The chosen library becoming unmaintained.
