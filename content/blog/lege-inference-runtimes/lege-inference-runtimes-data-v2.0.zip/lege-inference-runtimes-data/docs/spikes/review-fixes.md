# Review fixes: what the three reviews asked for, and what we found

Run 2026-11-10 to 12 on branch `spike/review` (from `spike/v6`). Three
reviews of the inference-library report and blog post (an OCR expert, a Rust
and performance expert, and a reviewer of scientific reports) produced 24
findings. This note lists each with what was done. The results are written up
in version 2.0 of the report (`docs/reports/inference-runtimes/report.typ`).
Result files are in `spikes/runtimes/results/review/`.

The reviews, like the original study, were carried out by Claude Code. They are
adversarial self-reviews, not independent peer review.

## Short answer

- **ONNX Runtime stays the choice, now with line-parallel threading.** Microsoft's
  build is fastest on one Linux x86-64 thread: RTen takes 1.80× as long (95%
  interval 1.76–1.84), tract 2.29×.
- **ONNX Runtime's output depends on the thread count, below what ALTO shows.**
  Its raw model outputs differ between 1 and N threads with Nix's build on the
  Mac and with Microsoft's build on ARM64 (not on x86-64). The first value that
  differs comes out of a large 1×1 convolution, which fits a matrix multiply
  splitting its sums across threads. tract and RTen were bit-identical at 1, 2,
  4 and 8 threads everywhere.
- **Line-parallel threading fixes it for every library.** Each model call runs on
  one thread and lines are read in parallel (`LEGE_SPIKE_PARALLEL=lines`). Raw
  outputs were then bit-identical at every thread count for all three libraries,
  and the ALTO check passed on all 25 images on the Mac and both Linux machines,
  including PP-OCRv6 small where Microsoft's build had failed. It takes about a
  third longer at 4 threads on the Mac, mostly because the detector then runs
  on one thread, and costs nothing on one thread.
- **Build settings change nothing.** LTO with one codegen unit, RTen's
  prepacked weights and ONNX Runtime's memory pattern are all within the 4%
  run-to-run noise. Letting ONNX Runtime's threads spin saves 9% at 4 threads on
  the Mac.
- **The 10% tie margin is justified:** run totals differed by a median of 0.4%
  and at most 4.1% across 32 build-and-machine combinations.
- **Memory was labelled wrong:** every figure was GiB (2^30 bytes) labelled GB.

## The 24 findings

| # | Finding | What was done |
|---|---|---|
| 1 | Disclose AI assistance, name authors | Authorship and AI-assistance statement in the report and the post |
| 2 | The rule's "shipped build" clause was written knowing the Nix build had failed | Said plainly in the rule section; without it RTen wins |
| 3 | Label the PP-OCRv6 work exploratory | Done, with the post hoc choices listed |
| 4 | Evidence not reachable (private repository) | Data archive published with the post (`spikes/runtimes/make-bundle.sh`) |
| 5 | The v6 addendum contradicts the body; no version number | v6 integrated; version 2.0 with a change log; old PDFs kept as versioned files |
| 6 | GiB labelled GB | Relabelled in the report, charts, bench tables, v6 note and post |
| 7 | Abstract overclaims | "Emulated" CPUs; under 2 GB only with v5; the tract fix is partial |
| 8 | Say what each timer covers | Defined; process time (`wall_s`) now saved and reported |
| 9 | tract recompiles per width; whole cache cleared at 49 | Least-recently-used eviction; opt-in width buckets (`LEGE_SPIKE_WIDTH_BUCKET`, recorded in the ALTO) measured |
| 10 | Memory: heap, and medium on Linux | Counting allocator (`--features heap-stats`); medium measured on Linux x86-64 |
| 11 | Build settings and tuning; time Microsoft's build | `release-lto` profile, RTen prepacking, ONNX Runtime memory pattern, optimized-graph cache, spinning; Microsoft's build timed on all machines |
| 12 | Setup against steady state | `--warm-with` runs on all machines |
| 13 | Mac core types | Stated as a limitation (not controllable from user space) |
| 14 | Pooled error rates with counts and intervals | `spikes/runtimes/accuracy2.py` |
| 15 | Draft transcriptions favour v5 | Stated as a limitation; checklist for a human check in `tests/fixtures/reference/ground-truth-drafts/CHECKLIST.md` |
| 16 | Detection metric | Line counts against the transcriptions; boxes matched to v5's at IoU 0.5 |
| 17 | v6 in its intended settings | Published detector settings found (box 0.45 for small and medium, 3,000 candidates); accuracy rerun; threshold sweep; error classes; input resizing checked |
| 18 | Uncertainty for speed | Per-run totals, spread, bootstrap intervals on ratios (`spikes/runtimes/summarise_review.py`) |
| 19 | Line-parallel threading | Implemented for all three libraries and measured |
| 20 | Find the first operator that differs | `crates/lege-ppocr/examples/ort_probe.rs`, `spikes/runtimes/ort_expose.py`: the eighth 1×1 convolution |
| 21 | Time on real old hardware | Not done, by decision; construct validity added to the threats |
| 22 | Broader workload | Three full-size newspaper pages (stress test, no ground truth); cross-machine output differences discussed |
| 23 | Sessions keyed by role | Keyed by model hash, thread count and threading mode |
| 24 | Thread count in a global; copies; finding the ONNX Runtime library | Thread count on `Executor`; input copy removed; library location and version check designed in the report's decision |

## Results added after the first draft

- **Microsoft's build, raw outputs:** identical across thread counts on Linux
  x86-64; different on Linux ARM64 and on a GitHub macOS runner (M2 Pro), up to
  47 of 523 model calls. Line-parallel: identical on all three.
- **PP-OCRv6 accuracy with the published detector settings** (12 scanned pages,
  16,080 characters; pooled error rate, 95% bootstrap interval):

  | Models | Edits | Error rate | Difference from v5, points |
  |---|---|---|---|
  | v5 (approved) | 58 | 0.36% (0.20–0.66) | — |
  | v6 tiny | 195 | 1.21% (0.72–1.83) | +0.34 to +1.43 |
  | v6 small | 78 | 0.49% (0.23–0.82) | −0.24 to +0.44 |
  | v6 medium | 60 | 0.37% (0.21–0.56) | −0.28 to +0.25 |
  | hybrid small | 37 | 0.23% (0.16–0.32) | −0.37 to +0.02 |
  | hybrid medium | 42 | 0.26% (0.20–0.36) | −0.34 to +0.05 |

  The hybrid small is the first set that may beat v5 (most of the gap is two
  pages, one where v5 splits printed lines), but the interval includes zero and
  the transcriptions favour v5. The threshold sweep moves the hybrid between 37
  and 47 edits; no setting fixes v6 tiny's garbled synthetic line. Version 1.1's
  "no gain" holds for the full v6 sets only.
- **Heap (PP-OCRv5, Linux):** tract 0.36 GiB, RTen 0.38 GiB; width buckets take
  tract to 0.26 GiB. tract's 1 GiB resident peak on the Mac is macOS's counting.
- **PP-OCRv6 medium on Linux:** tract 2.65 GiB resident (2.62 GiB heap), over the
  limit; width buckets bring it to 1.62 GiB. RTen 1.24, ONNX Runtime 1.43.
- **Optimized-graph cache:** 2% faster on one thread, same output. Not worth it.
- **Newspapers** (three Chronicling America front pages, up to 5,880 × 8,600
  pixels, 855 lines): same ALTO at 1 and 2 threads for every library and mode;
  ONNX Runtime fastest; **ONNX Runtime peaked at 2.07 GiB resident, over the
  2 GB limit** (Lege's heap 0.35 GiB). RTen 1.67 GiB, tract 1.25 GiB. The
  decision now requires bringing ONNX Runtime under the limit on such pages
  (arena off, or tiling) before shipping.
- **Not done:** the Mac's steady-state, heap and newspaper runs were cut short
  three times by the laptop losing power; they were replaced by Linux runs (and
  the macOS raw check by a GitHub macOS runner).
