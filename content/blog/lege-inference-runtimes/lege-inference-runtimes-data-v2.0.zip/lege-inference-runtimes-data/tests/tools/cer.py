#!/usr/bin/env python3
"""CER/WER (Levenshtein, NFC-normalized, no pass/fail floor: ADR-0013, REQ-PPOCR-001).
Usage: cer.py GT.txt HYP.txt [GT2 HYP2 ...]   -> TSV report on stdout."""
import sys
import unicodedata


def _lev(a, b):
    prev = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        cur = [i]
        for j, y in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x != y)))
        prev = cur
    return prev[-1]


def _n(s):
    return unicodedata.normalize("NFC", s).strip("\n")


def cer(gt: str, hyp: str) -> float:
    g, h = _n(gt), _n(hyp)
    return _lev(g, h) / max(1, len(g))


def wer(gt: str, hyp: str) -> float:
    g, h = _n(gt).split(), _n(hyp).split()
    return _lev(g, h) / max(1, len(g))


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or len(a) % 2:
        sys.exit(__doc__)
    print("gt\thyp\tcer\twer")
    for g, h in zip(a[::2], a[1::2]):
        G, H = open(g, encoding="utf-8").read(), open(h, encoding="utf-8").read()
        print(f"{g}\t{h}\t{cer(G, H):.4f}\t{wer(G, H):.4f}")
