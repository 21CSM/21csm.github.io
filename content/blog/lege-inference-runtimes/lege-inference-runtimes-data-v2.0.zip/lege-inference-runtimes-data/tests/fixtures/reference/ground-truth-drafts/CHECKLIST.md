# Checking the draft transcriptions by eye

The 12 drafts here were made by correcting Lege's PP-OCRv5 output (see
`REVIEW.md`). Words where Lege and the book agreed were not checked one by
one, so any accuracy comparison against these drafts favours PP-OCRv5. The
inference-library report states this as a limitation. This checklist is for
a person who reads each scan against its draft and removes that bias.

## How to check one page

1. Open the scan (`tests/fixtures/reference/images/<id>.*`) and the draft
   (`<id>.draft.txt`) side by side, at a zoom where every letter is clear.
2. Read the draft line by line against the scan. Check every word, not just
   the ones that look wrong: the risk is an error that reads naturally.
3. Follow the conventions in `REVIEW.md` (straight quotes, one line per
   printed row, line-end hyphens as printed, misprints kept as printed).
4. Fix the draft in place. Note each change in the table below.
5. When the page is done, tick it and add your initials and the date.

Promote a checked page to ground truth as `REVIEW.md` describes (move it to
`ground-truth/`, set `ground_truth` and `ground_truth_sha256` in the manifest).

## Pages, highest risk first

Scan-only pages have no second source, so Lege's reading was the only text.

| Done | Page | Why it matters | Changes made | Checked by, date |
|---|---|---|---|---|
| [ ] | `pd-aurelius-meditations-1887-n100` | scan only | | |
| [ ] | `pd-mickiewicz-pisma-1877-n120` | scan only, Polish diacritics | | |
| [ ] | `pd-goodytwoshoes-1888-n8` | scan only, decorative caption | | |
| [ ] | `pd-kafka-heizer-1913-n20` | `ch`/`ck` ligatures, German | | |
| [ ] | `pd-cervantes-quijote-1892-n300` | book is a modernized edition | | |
| [ ] | `pd-darwin-origin-1871-n150` | book is a later edition | | |
| [ ] | `pd-paine-commonsense-1920-n40` | edition differences, split rows | | |
| [ ] | `pd-thoreau-walden-1893-n150` | damaged letters, margin marks | | |
| [ ] | `pd-stevenson-treasure-1907-n120` | quotes | | |
| [ ] | `pd-hugo-miserables-1888-n150` | French accents | | |
| [ ] | `pd-baum-oz-1900-n60` | | | |
| [ ] | `pd-austen-pride-1894-n120` | | | |

After any change, re-run `spikes/runtimes/accuracy2.py` so the report's
accuracy tables use the checked text.
