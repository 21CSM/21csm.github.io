# Ground-truth drafts: review record

Status: **drafts, awaiting the maintainer's spot check.** The manifest does not point at these files,
so no test or report treats them as ground truth. To promote one, move it to `ground-truth/{id}.gt.txt`
and set `ground_truth` and `ground_truth_sha256` in the manifest.

How they were made: `tests/tools/gt_draft.py` found each page in the Project Gutenberg text of the same
book (usually a different edition) and listed where the book and Lege's approved snapshot disagree.
Each disagreement was then settled by reading the scan image, and the running heads and page numbers,
which the book doesn't have, were read off the scan too. **The scan decides, never the book.** Reviewer:
Claude Code, 2026-11-04. Words where the book and Lege agree were not checked one by one.

Conventions: straight quotes; one line per printed row; line-end hyphens as printed; spacing around
punctuation as Lege wrote it (`gotten :`, `" Most`), so spacing is not scored as an error.

## Disagreements (47)

38 Lege right, book differs from this scan. 2 spacing only. 7 Lege wrong.

| Page | Gutenberg | Lege right | Spacing only | Lege wrong |
|---|---|---|---|---|
| `pd-austen-pride-1894-n120` | 1342 | 1 (`exceedingly`, no full stop on this scan) | | |
| `pd-baum-oz-1900-n60` | 55 | 1 (`indeed;"`) | | |
| `pd-thoreau-walden-1893-n150` | 205 | | | 4: whole line missed (`I went to the woods because I wished to`); `c-n` for `can` on a damaged letter; `√` from a margin pencil mark; `in.` from a speck |
| `pd-stevenson-treasure-1907-n120` | 120 | 11 (e.g. `look out.`, `Mr. Trelawney, grandly`) | 2 (`" Most`) | 2: `And` lost its opening quote; `up.'` for `up."` |
| `pd-paine-commonsense-1920-n40` | 147 | 25 (edition: `waive`, `connections`, `hath`, `enmity (or enemy-ship`, ...) | | 1: stray `CA` |

Also corrected, outside the book's text: `9I` for page number `91` (Austen).

Layout, not in the table: 12 printed rows came out of Lege as more than one line (Paine 7, Walden 2,
1 each on the others). The drafts keep them as one line, so each costs one character in `cer.py`.

## Second batch (7 scans, 2026-11-05)

Same method and reviewer, except where there is no independent text.

| Page | Source | Lege errors corrected in the draft |
|---|---|---|
| `pd-darwin-origin-1871-n150` | Gutenberg 2009 (later edition) | `CHap.` for `CHAP.`, `sueh`, `cayes` |
| `pd-hugo-miserables-1888-n150` | Gutenberg 17489 | none |
| `pd-cervantes-quijote-1892-n300` | Gutenberg 2000 (modernized) | `I.-` for `I.—`, `principe` for `príncipe` |
| `pd-kafka-heizer-1913-n20` | Gutenberg 16304 | `ch`/`ck` ligature: `Shiffen`, `Rüken`, `Büherbrett`, `blidk`; also `volführte`, `ame=`, missed signature mark `2` |
| `pd-aurelius-meditations-1887-n100` | **scan only**: no matching translation found | none |
| `pd-mickiewicz-pisma-1877-n120` | **scan only**: no text found | `jezykiem`, `podziělała`, `materje` |
| `pd-goodytwoshoes-1888-n8` | **scan only**: one decorative caption | `Ploing Sq Tueman` |

Scan-only drafts have no second source, so these need the closest check. They start from Lege's text, so
an error that looks right when read could survive.

Printed misprints stay as printed: `lndzie` and `Petersbnrgu` (Mickiewicz) look like turned letters, and
Lege read them correctly. Kept unaccented as printed: `termino` (Cervantes). The double hyphen at line
ends in Kafka is written `-`. The ornaments either side of the Goody Two-Shoes caption are not transcribed.

## Lege against these drafts

`tests/tools/cer.py`, approved snapshots. Pooled over the 11 text pages: **0.27% CER** (44 edits in 16,050
characters). That is 11 pages from a reference set chosen to be varied, not a general accuracy figure.

| Scan | Language | CER | WER |
|---|---|---|---|
| `pd-hugo-miserables-1888-n150` | fr | 0.00% | 0.00% |
| `pd-austen-pride-1894-n120` | en | 0.11% | 0.31% |
| `pd-aurelius-meditations-1887-n100` | en | 0.13% | 0.00% |
| `pd-mickiewicz-pisma-1877-n120` | pl | 0.15% | 1.05% |
| `pd-stevenson-treasure-1907-n120` | en | 0.20% | 0.73% |
| `pd-cervantes-quijote-1892-n300` | es | 0.20% | 0.72% |
| `pd-darwin-origin-1871-n150` | en | 0.23% | 0.69% |
| `pd-baum-oz-1900-n60` | en | 0.24% | 0.00% |
| `pd-thoreau-walden-1893-n150` | en | 0.40% (3.61% before BOX-RESCUE) | 1.18% (4.71%) |
| `pd-kafka-heizer-1913-n20` | de | 0.54% | 2.94% |
| `pd-paine-commonsense-1920-n40` | en | 0.71% | 0.36% |
| `pd-goodytwoshoes-1888-n8` | en | 46.67% | 100% |

Derived variants, scored against their source's draft:

| Scan | CER | WER |
|---|---|---|
| `pd-thoreau-walden-1893-n150.tiff-lzw` | 0.40% | 1.18% |
| `pd-hugo-miserables-1888-n150.tiff-deflate` | 0.00% | 0.00% |
| `pd-kafka-heizer-1913-n20.tiff-lzw` | 0.54% | 2.94% |
| `pd-paine-commonsense-1920-n40.tiff-g4` | 2.45% | 4.29% |
| `pd-pride-1894-n120-flip` | 0.17% | 0.93% |
| `pd-walden-1893-n150-flip` | 0.80% | 1.96% |
| `pd-walden-1893-n150-flip.tiff-raw` | 0.80% | 1.96% |
| `pd-aurelius-meditations-1887-n100-rot180` | 81.27% | 97.58% |

Most of Walden's earlier error was the one missed line, since fixed (spec-gaps.md BOX-RESCUE). The first
batch's tally describes the review, before that fix.

## Findings

- **Goody Two-Shoes:** decorative lettering on an illustration fails. Expected for this model.
- **Kafka:** the `ch`/`ck` ligatures of this typeface account for most of its errors.
- **G4 TIFF:** black-and-white compression roughly triples Paine's error rate.
- **Page scanned upside down (`-rot180`):** bottom-to-top reading order is accepted (spec-gaps.md), and it
  inflates this score. But the page also breaks into 221 lines instead of 34, with garbled text
  (`fo mmd pe`), which that decision doesn't cover. Whole-page rotation is outside v0.1 (spec.md), so this
  is recorded, not fixed.
