# Data and code for "Choosing an inference library for Lege"

Everything behind the report's tables: the raw result files, the scripts and
GitHub Actions workflows that produced them, the decision rule as committed,
the spike write-ups, the report source (Typst), the reference transcriptions,
and the model-fetching script with its pinned hashes.

- `spikes/runtimes/results/`: result files. Version 1 files sit at the top;
  `v6/` holds the PP-OCRv6 runs; `review/` the runs made for version 2.
- `spikes/runtimes/*.py`, `*.sh`: the benchmark, checks and analysis scripts.
- `docs/spikes/`: decision rule and write-ups.
- `docs/reports/inference-runtimes/report.typ`: the report source.

Local paths in the result files are replaced by `<scratch>`, `~` and
`<checkout>`. Lege's source code is not public and is not included, so the
runs cannot be repeated from this archive alone; every number can be checked
against its result file, and every analysis rerun. Licence for the scripts:
MIT OR Apache-2.0.
