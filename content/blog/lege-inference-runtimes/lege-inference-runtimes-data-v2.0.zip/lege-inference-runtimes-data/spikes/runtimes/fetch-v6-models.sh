#!/bin/sh
# MODEL SPIKE: fetch one PP-OCRv6 size into DEST as det.onnx, cls.onnx, rec.onnx
# and dict.txt, pinned by Hugging Face revision and SHA-256.
#
# No PP-OCRv6 direction classifier is published, so cls.onnx is the same
# PP-LCNet_x0_25_textline_ori file Lege uses with PP-OCRv5, copied from V5DIR
# (a folder filled by scripts/fetch-ppocr-models.sh).
#
# With a fourth argument `v5-recognizer`, only the PP-OCRv6 detector is fetched
# and rec.onnx and dict.txt are PP-OCRv5's Latin recognizer and dictionary from
# V5DIR: the "v6 detector, v5 recognizer" hybrid.
#
# Usage: fetch-v6-models.sh tiny|small|medium DEST V5DIR [v5-recognizer]
set -eu
size=$1 dest=$2 v5=$3 mode=${4:-}
here=$(cd "$(dirname "$0")" && pwd)

case "$size" in
    tiny)
        det_rev=2ba1506c0380b8f0b03dd142459aac66d4421f6c det_sha=193bab7a04fca699a6c82e6abb5b81bdb28177f0abd4062552b04908dafb19f8
        rec_rev=2612ab37152ae0a677521bae4e1e3d4fb4cf7c30 rec_sha=9ef676d6ed3c88256a2d92c640c44f25b0c40947e111b14b8be8f594091563e6
        yml_sha=66170210bad538e83fff3c4a3867e547d6bf20b50d64b20347c4b913f3034ea1
        dict_sha=c5cbe34ef40c29c4df07ed012bf96569cb69a2d2a01a07027e9f13cb832bd9cd ;;
    small)
        det_rev=28fe5895c24fd108c19eb3e8479f4ab385fbfc62 det_sha=d73e0058b7a8086bbd57f3d10b8bcd4ff95363f67e06e2762b5e814fe9c9410e
        rec_rev=b8f84f0b80c529de40b4fbb3544b84fa7233a513 rec_sha=5435fd747c9e0efe15a96d0b378d5bd157e9492ed8fd80edf08f30d02fa24634
        yml_sha=ab078671bb49f06228eadccd34f1bb501e157f7a047095ffb943ba81512c77d1
        dict_sha=b5f2bfe2bdd9448429e3e82b51c789775d9b42f2403d082b00662eb77e401c5d ;;
    medium)
        det_rev=61323801669c338b7891481ec7bac61ce31b576a det_sha=eb13b44b25bb36f89528b68720af8a61d9cf381176107f465db1757b65d086e1
        rec_rev=50c7eacafc52fa7bcf4194e8cd08e46f8558504b rec_sha=9c09abf0957f7968c7586464b7397b84ad2387a0497a351af40e9acc71b673ba
        yml_sha=991b700facf5b50a7de193468207d5f4255b538dde0d312ae3b7c7a9b6873129
        dict_sha=b5f2bfe2bdd9448429e3e82b51c789775d9b42f2403d082b00662eb77e401c5d ;;
    *) echo "size must be tiny, small or medium" >&2; exit 2 ;;
esac

sha() { if command -v sha256sum >/dev/null; then sha256sum "$1"; else shasum -a 256 "$1"; fi | cut -d' ' -f1; }
check() {
    actual=$(sha "$1")
    [ "$actual" = "$2" ] || { echo "SHA-256 mismatch for $1: $actual, pinned $2" >&2; exit 1; }
}
get() { # repo revision file dest sha
    if [ -f "$4" ] && [ "$(sha "$4")" = "$5" ]; then return; fi
    curl -fsSL -o "$4" "https://huggingface.co/PaddlePaddle/$1/resolve/$2/$3"
    check "$4" "$5"
}

mkdir -p "$dest"
get "PP-OCRv6_${size}_det_onnx" "$det_rev" inference.onnx "$dest/det.onnx" "$det_sha"
if [ "$mode" = v5-recognizer ]; then
    cp "$v5/rec.onnx" "$dest/rec.onnx"
    check "$dest/rec.onnx" 7888113072263cb471b93f66dd5e2ad70548dc526fa1ace760d0d973dd121498
    cp "$v5/dict.txt" "$dest/dict.txt"
    check "$dest/dict.txt" ccbcc45730b3fbbd9050c5bc74db6a99067141ef1035e3d14889a84a6b9b1aff
else
    get "PP-OCRv6_${size}_rec_onnx" "$rec_rev" inference.onnx "$dest/rec.onnx" "$rec_sha"
    get "PP-OCRv6_${size}_rec_onnx" "$rec_rev" inference.yml "$dest/rec.yml" "$yml_sha"
    python3 -I "$here/v6_dict.py" "$dest/rec.yml" "$dest/dict.txt"
    check "$dest/dict.txt" "$dict_sha"
fi
cp "$v5/cls.onnx" "$dest/cls.onnx"
check "$dest/cls.onnx" 94a6a0a0425f2b5f08b5df72086f2d72abe40f1d22f6d12d2cd83674f11f2ff3
echo "PP-OCRv6 $size ${mode:+($mode) }in $dest"
