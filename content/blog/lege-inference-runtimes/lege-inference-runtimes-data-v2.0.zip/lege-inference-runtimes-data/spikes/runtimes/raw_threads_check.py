#!/usr/bin/env python3
"""REVIEW SPIKE: does any model's raw output change with the thread count?

threads_check.py compares ALTO files, where confidences are rounded to four
decimals, so a library whose raw numbers change in the last bits passes it
unless a rounding boundary happens to be crossed. This compares the model
outputs themselves, bit for bit: each image is run once per thread count with
LEGE_SPIKE_DUMP set, and every output file is compared with the 1-thread run.

Prints, per binary and thread count, how many model calls gave bit-different
output (by stage) and the largest absolute difference. Writes raw.json.

With --unordered (for per-line threading, where calls finish in any order and
the dump numbering follows completion), each stage's outputs are compared as a
multiset of hashes instead: equal multisets mean every call gave exactly the
1-thread output.

Usage: raw_threads_check.py --models DIR --out DIR --bin NAME=PATH [...]
       [--threads 1,4] [--images ID,ID] [--env NAME:KEY=VALUE ...]
"""
import argparse
import hashlib
import json
import os
import shutil
import struct
import subprocess
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REF = ROOT / "tests" / "fixtures" / "reference"


def outputs(folder: Path):
    return sorted(p for p in folder.iterdir() if "-out-" in p.name)


def compare(a: Path, b: Path):
    x, y = a.read_bytes(), b.read_bytes()
    if x == y:
        return 0, 0.0
    fa = struct.unpack(f"<{len(x) // 4}f", x)
    fb = struct.unpack(f"<{len(y) // 4}f", y)
    if len(fa) != len(fb):
        return -1, float("inf")
    differ = sum(1 for p, q in zip(fa, fb) if p != q)
    return differ, max(abs(p - q) for p, q in zip(fa, fb))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", required=True)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--bin", action="append", default=[])
    ap.add_argument("--threads", default="1,4")
    ap.add_argument("--images", default="")
    ap.add_argument("--env", action="append", default=[])
    ap.add_argument("--unordered", action="append", default=[], help="binary names to compare as multisets")
    a = ap.parse_args()
    threads = [int(t) for t in a.threads.split(",")]
    entries = json.loads((REF / "manifest.json").read_text())["entries"]
    if a.images:
        entries = [e for e in entries if e["id"] in a.images.split(",")]
    envs = defaultdict(dict)
    for spec in a.env:
        name, kv = spec.split(":", 1)
        k, v = kv.split("=", 1)
        envs[name][k] = v
    report = {}
    for name, binary in (b.split("=", 1) for b in a.bin):
        per_t = {}
        for e in entries:
            dirs = {}
            for t in threads:
                d = a.out / name / e["id"] / f"t{t}"
                shutil.rmtree(d, ignore_errors=True)
                (d / "dump").mkdir(parents=True)
                env = {**os.environ, **envs[name], "LEGE_SPIKE_DUMP": str(d / "dump")}
                subprocess.run([binary, "--models", a.models, "--out-dir", str(d), "--threads", str(t),
                                str(REF / e["file"])], env=env, check=True, capture_output=True)
                dirs[t] = d / "dump"
            base = outputs(dirs[threads[0]])

            def multiset(files):
                out = defaultdict(list)
                for f in files:
                    out[f.name.split("-out-")[1].rsplit("-", 1)[0]].append(hashlib.sha256(f.read_bytes()).hexdigest())
                return {k: sorted(v) for k, v in out.items()}

            for t in threads[1:]:
                if name in a.unordered:
                    other = outputs(dirs[t])
                    row = per_t.setdefault(str(t), {"calls": 0, "differ": defaultdict(int), "max": 0.0, "unordered": True})
                    mb, mo = multiset(base), multiset(other)
                    row["calls"] += len(base)
                    for stage in set(mb) | set(mo):
                        x, y = mb.get(stage, []), mo.get(stage, [])
                        # Calls whose output has no identical partner in the other run.
                        from collections import Counter
                        missing = sum((Counter(x) - Counter(y)).values())
                        if missing:
                            row["differ"][stage] += missing
                    continue
                other = outputs(dirs[t])
                row = per_t.setdefault(str(t), {"calls": 0, "differ": defaultdict(int), "max": 0.0})
                if len(other) != len(base):
                    row["differ"]["call count"] += 1
                    continue
                for p, q in zip(base, other):
                    stage = p.name.split("-out-")[1].rsplit("-", 1)[0]
                    row["calls"] += 1
                    n, m = compare(p, q)
                    if n:
                        row["differ"][stage] += 1
                        row["max"] = max(row["max"], m)
            for t in threads:
                shutil.rmtree(dirs[t], ignore_errors=True)
        report[name] = per_t
        for t, row in per_t.items():
            print(f"{name} t{t}: {row['calls']} model calls, bit-different: "
                  f"{dict(row['differ']) or 'none'}, largest difference {row['max']:.3g}", flush=True)
    a.out.mkdir(parents=True, exist_ok=True)
    (a.out / "raw.json").write_text(json.dumps(report, indent=2, default=dict))


if __name__ == "__main__":
    main()
