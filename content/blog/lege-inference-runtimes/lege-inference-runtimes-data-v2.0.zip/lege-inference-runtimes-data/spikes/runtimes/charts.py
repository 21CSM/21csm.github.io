#!/usr/bin/env python3
"""Draw the runtime spike's charts as SVG, straight from the result files.

Every number in a chart is read from the JSON that bench.py (or a recorded
measurement) wrote, so the report cannot drift from the data.

Usage:
  charts.py --out DIR --machine "Mac M3 Pro=results/mac-m3pro.json" [--machine ...]
            [--gpu results/mac-m3pro-gpu.json]

Writes speed.svg, memory.svg and, with --gpu, gpu.svg.
"""
import argparse
import json
from html import escape
from pathlib import Path

LIBS = [("tract", "tract"), ("rten", "RTen"), ("ort", "ONNX Runtime")]
FONT = "Helvetica, Arial, sans-serif"
INK, QUIET, GRID, ACCENT, MUTED = "#1f2328", "#59636e", "#d8dee4", "#2f6fdb", "#9aa4ae"


def text(x, y, s, size=12, fill=INK, anchor="start", weight="normal"):
    return (f'<text x="{x:.1f}" y="{y:.1f}" font-family="{FONT}" font-size="{size}" '
            f'fill="{fill}" text-anchor="{anchor}" font-weight="{weight}">{escape(str(s))}</text>')


def svg(width, height, body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
            f'width="{width}" height="{height}"><rect width="100%" height="100%" fill="white"/>'
            + "".join(body) + "</svg>\n")


def totals(results, lib):
    """Total median seconds over all images, per thread count."""
    out = {}
    for t, images in results["runtimes"][lib]["threads"].items():
        ok = [v["page_ms"] for v in images.values() if not v.get("failed")]
        out[int(t)] = sum(ok) / 1000
    return out


def peak_gb(results, lib):
    rss = [v["rss"] for d in results["runtimes"][lib]["threads"].values() for v in d.values() if not v.get("failed")]
    return max(rss) / 2**30


def nice_max(v, step):
    return step * (int(v / step) + 1)


def speed_chart(machines):
    """One panel per machine: a row per library, 1 thread (light) to most threads (dark)."""
    width, x0, x1 = 760, 160, 700
    vmax = nice_max(max(s for _, r in machines for lib, _ in LIBS for s in totals(r, lib).values()), 20)
    x = lambda v: x0 + v / vmax * (x1 - x0)
    body = [text(20, 28, "Total time for the 25 reference pages, by thread count", 16, weight="bold"),
            text(20, 48, "Median of 3 runs per page; lighter dot = 1 thread, darker dot = most threads measured", 12, QUIET)]
    y = 80
    for label, r in machines:
        tmax = max(int(t) for t in r["runtimes"]["tract"]["threads"])
        body.append(text(20, y + 4, f"{label} ({r.get('cores', '?')} logical cores; darker = {tmax} threads)", 13, weight="bold"))
        y += 22
        for lib, name in LIBS:
            if lib not in r["runtimes"]:
                continue
            tt = totals(r, lib)
            a, b = tt[1], tt[tmax]
            body.append(text(20, y + 4, name, 12))
            body.append(f'<line x1="{x(b):.1f}" x2="{x(a):.1f}" y1="{y}" y2="{y}" stroke="{ACCENT}" stroke-opacity="0.35" stroke-width="3"/>')
            body.append(f'<circle cx="{x(a):.1f}" cy="{y}" r="6" fill="{ACCENT}" fill-opacity="0.35"/>')
            body.append(f'<circle cx="{x(b):.1f}" cy="{y}" r="6" fill="{ACCENT}"/>')
            if tmax != 1:
                body.append(text(x(b) - 10, y + 4, f"{b:.1f} s", 11, anchor="end"))
            body.append(text(x(a) + 10, y + 4, f"{a:.1f} s", 11, QUIET))
            y += 24
        y += 14
    for t in range(0, int(vmax) + 1, 20):
        body.insert(2, f'<line x1="{x(t):.1f}" x2="{x(t):.1f}" y1="66" y2="{y - 10}" stroke="{GRID}"/>')
        body.append(text(x(t), y + 6, f"{t} s", 11, QUIET, "middle"))
    return svg(width, y + 20, body)


def memory_chart(machines):
    width, x0, x1 = 760, 160, 640
    vmax = nice_max(max(peak_gb(r, lib) for _, r in machines for lib, _ in LIBS if lib in r["runtimes"]), 0.5)
    vmax = max(vmax, 2.0)
    x = lambda v: x0 + v / vmax * (x1 - x0)
    body = [text(20, 28, "Peak memory on any of the 25 pages", 16, weight="bold"),
            text(20, 48, "Maximum resident set size of the lege process; in GiB (2^30 bytes); the dashed line is the decision rule's 2 GB limit, 1.86 GiB", 12, QUIET)]
    y = 80
    for label, r in machines:
        body.append(text(20, y + 4, label, 13, weight="bold"))
        y += 20
        for lib, name in LIBS:
            if lib not in r["runtimes"]:
                continue
            g = peak_gb(r, lib)
            body.append(text(20, y + 12, name, 12))
            body.append(f'<rect x="{x0}" y="{y}" width="{x(g) - x0:.1f}" height="16" fill="{MUTED}"/>')
            body.append(text(x(g) + 8, y + 12, f"{g:.2f} GiB", 11))
            y += 22
        y += 12
    lim = 2e9 / 2**30  # the rule's 2 GB, in GiB
    body.append(f'<line x1="{x(lim):.1f}" x2="{x(lim):.1f}" y1="66" y2="{y - 6}" stroke="{INK}" stroke-dasharray="4 3"/>')
    body.append(text(x(lim) + 4, 64, "2 GB limit (1.86 GiB)", 11, QUIET))
    return svg(width, y + 10, body)


def gpu_chart(g):
    width, x0, x1 = 760, 300, 700
    opts = sorted(g["options"], key=lambda o: o["t4"])
    vmax = nice_max(max(o["t4"] for o in opts) / 1000, 1)
    x = lambda v: x0 + v / vmax * (x1 - x0)
    best = min(o["t4"] for o in opts if o["kind"] == "CPU") / 1000
    body = [text(20, 28, "Every GPU and Neural Engine option was slower than 4 CPU threads", 16, weight="bold"),
            text(20, 48, "Seconds to read one 34-line page after reading a different page first; Mac M3 Pro, 4 threads", 12, QUIET)]
    y = 76
    for o in opts:
        v = o["t4"] / 1000
        body.append(text(20, y + 13, o["name"], 12))
        body.append(f'<rect x="{x0}" y="{y}" width="{x(v) - x0:.1f}" height="18" fill="{MUTED if o["kind"] == "CPU" else ACCENT}"/>')
        body.append(text(x(v) + 8, y + 13, f"{v:.2f} s", 11))
        y += 28
    body.append(f'<line x1="{x(best):.1f}" x2="{x(best):.1f}" y1="66" y2="{y}" stroke="{INK}" stroke-dasharray="4 3"/>')
    body.append(text(x(best) + 4, 64, "fastest CPU option", 11, QUIET))
    for t in range(0, int(vmax) + 1):
        body.append(text(x(t), y + 18, f"{t} s", 11, QUIET, "middle"))
    return svg(width, y + 30, body)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--machine", action="append", default=[], help="label=results.json")
    ap.add_argument("--gpu", type=Path)
    a = ap.parse_args()
    machines = [(m.split("=", 1)[0], json.loads(Path(m.split("=", 1)[1]).read_text())) for m in a.machine]
    a.out.mkdir(parents=True, exist_ok=True)
    (a.out / "speed.svg").write_text(speed_chart(machines))
    (a.out / "memory.svg").write_text(memory_chart(machines))
    if a.gpu:
        (a.out / "gpu.svg").write_text(gpu_chart(json.loads(a.gpu.read_text())))
    print("wrote", ", ".join(p.name for p in sorted(a.out.glob("*.svg"))))


if __name__ == "__main__":
    main()
