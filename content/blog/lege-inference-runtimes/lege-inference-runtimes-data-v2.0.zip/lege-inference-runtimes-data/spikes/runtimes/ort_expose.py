#!/usr/bin/env python3
"""REVIEW SPIKE: write a copy of an ONNX model whose every intermediate float
value is also a graph output, in node order, so ort_probe can compare them at
several thread counts.

Exposing values can stop ONNX Runtime from fusing the operators that produce
them, so a mismatch seen in the plain model may not reproduce here; ort_probe
on the plain model (final output only) checks that first.

Usage: ort_expose.py MODEL.onnx OUT.onnx
"""
import sys

import onnx
from onnx import TensorProto, helper


def main():
    model = onnx.shape_inference.infer_shapes(onnx.load(sys.argv[1]))
    graph = model.graph
    types = {v.name: v.type.tensor_type.elem_type for v in graph.value_info}
    have = {o.name for o in graph.output}
    for node in graph.node:
        for name in node.output:
            # Only values shape inference marks as float; others are skipped.
            if name and name not in have and types.get(name) == TensorProto.FLOAT:
                graph.output.append(helper.make_tensor_value_info(name, TensorProto.FLOAT, None))
                have.add(name)
    onnx.save(model, sys.argv[2])
    print(f"{sys.argv[2]}: {len(graph.output)} outputs")


if __name__ == "__main__":
    main()
