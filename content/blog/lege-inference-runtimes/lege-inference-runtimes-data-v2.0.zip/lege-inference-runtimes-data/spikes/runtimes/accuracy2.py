#!/usr/bin/env python3
"""REVIEW SPIKE: accuracy of model sets against the reference transcriptions,
reported the way the peer review asked.

For every model set (a bench.py output folder) and PP-OCRv5's approved
snapshot:

* Character errors: Levenshtein edits and reference characters per page (NFC,
  as tests/tools/cer.py), then the pooled rate (total edits / total characters)
  for the 4 synthetic lines and the 12 draft pages separately. Pooling weighs
  each page by its length, so no page has to be dropped. A 95% interval comes
  from 10,000 bootstrap resamples of pages (fixed seed).
* Paired comparison with v5: the bootstrap also resamples the difference in
  pooled rate against v5 on the same pages, so the interval answers "is this
  set better or worse than v5 on these pages".
* Error classes (approximate): difflib's alignment of reference and output,
  counting each mismatched reference or output character as a letter, digit,
  space, ASCII punctuation, full-width or CJK character, or other.
* Lines: the number of text lines found against the number in the
  transcription (a ground-truth check on the detector), and line boxes matched
  to the v5 snapshot's ALTO at intersection-over-union 0.5 (how far the
  detector's lines move from v5's; v5 is not ground truth for boxes).

Usage: accuracy2.py --run NAME=BENCH_DIR [...] --out accuracy2.json
       (text and ALTO are read from BENCH_DIR/<first library>/t<first threads>/r<last>/)
"""
import argparse
import difflib
import json
import random
import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests" / "tools"))
from cer import _lev  # noqa: E402

REF = ROOT / "tests" / "fixtures" / "reference"
V5 = "PP-OCRv5 mobile (approved snapshot)"


def nfc(s):
    return unicodedata.normalize("NFC", s).strip("\n")


def transcriptions():
    out = []
    for p in sorted((REF / "ground-truth").glob("*.gt.txt")):
        out.append(("ground truth", p.name.removesuffix(".gt.txt"), p.read_text()))
    for p in sorted((REF / "ground-truth-drafts").glob("*.draft.txt")):
        out.append(("drafts", p.name.removesuffix(".draft.txt"), p.read_text()))
    return out


def find(bench: Path, stem: str, suffix: str):
    hits = sorted(bench.glob(f"*/t*/r*/{stem}{suffix}"))
    return hits[-1] if hits else None


def char_class(c):
    if c.isspace():
        return "space"
    if unicodedata.east_asian_width(c) in "FW" or "CJK" in unicodedata.name(c, ""):
        return "full-width or CJK"
    if c.isalpha():
        return "letter"
    if c.isdigit():
        return "digit"
    if c.isascii() and not c.isalnum():
        return "ASCII punctuation"
    return "other"


def error_classes(ref, hyp):
    counts = {}
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, ref, hyp, autojunk=False).get_opcodes():
        if op == "equal":
            continue
        for c in ref[i1:i2] + hyp[j1:j2]:
            k = char_class(c)
            counts[k] = counts.get(k, 0) + 1
    return counts


BOX = re.compile(r'<TextLine\b[^>]*?HPOS="([\d.]+)"[^>]*?VPOS="([\d.]+)"[^>]*?WIDTH="([\d.]+)"[^>]*?HEIGHT="([\d.]+)"')


def boxes(alto_path):
    if alto_path is None or not alto_path.exists():
        return None
    return [tuple(map(float, m)) for m in BOX.findall(alto_path.read_text())]


def iou(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ix = max(0.0, min(ax + aw, bx + bw) - max(ax, bx))
    iy = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    inter = ix * iy
    union = aw * ah + bw * bh - inter
    return inter / union if union else 0.0


def match(ref, hyp, threshold=0.5):
    """Greedy one-to-one matching by IoU; returns matched pairs."""
    pairs = sorted(((iou(r, h), i, j) for i, r in enumerate(ref) for j, h in enumerate(hyp)), reverse=True)
    used_r, used_h, n = set(), set(), 0
    for score, i, j in pairs:
        if score < threshold:
            break
        if i in used_r or j in used_h:
            continue
        used_r.add(i)
        used_h.add(j)
        n += 1
    return n


def bootstrap(pages, names, rng, n=10000):
    """95% intervals for each set's pooled rate and its difference from v5."""
    out = {name: {"rate": [], "diff": []} for name in names}
    k = len(pages)
    for _ in range(n):
        sample = [pages[rng.randrange(k)] for _ in range(k)]
        chars = sum(p["chars"] for p in sample)
        v5 = sum(p["sets"][V5]["edits"] for p in sample) / chars
        for name in names:
            r = sum(p["sets"][name]["edits"] for p in sample) / chars
            out[name]["rate"].append(r)
            out[name]["diff"].append(r - v5)

    def ci(xs):
        xs = sorted(xs)
        return [xs[int(0.025 * len(xs))], xs[int(0.975 * len(xs)) - 1]]

    return {name: {"rate_95": ci(v["rate"]), "diff_vs_v5_95": ci(v["diff"])} for name, v in out.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", action="append", default=[])
    ap.add_argument("--out", required=True, type=Path)
    a = ap.parse_args()
    runs = {V5: None} | {r.split("=", 1)[0]: Path(r.split("=", 1)[1]) for r in a.run}
    pages = []
    for kind, stem, truth in transcriptions():
        ref = nfc(truth)
        exp_alto = REF / "expected" / f"{stem}.alto.xml"
        v5_boxes = boxes(exp_alto)
        page = {"kind": kind, "page": stem, "chars": len(ref), "ref_lines": len(ref.splitlines()), "sets": {}}
        for name, bench in runs.items():
            if bench is None:
                hyp_path, alto_path = REF / "expected" / f"{stem}.txt", exp_alto
            else:
                hyp_path, alto_path = find(bench, stem, ".txt"), find(bench, stem, ".alto.xml")
            if hyp_path is None:
                raise SystemExit(f"{name}: no output for {stem} in {bench}")
            hyp = nfc(hyp_path.read_text())
            b = boxes(alto_path)
            page["sets"][name] = {
                "edits": _lev(ref, hyp),
                "lines": len(hyp.splitlines()),
                "errors_by_class": error_classes(ref, hyp),
                "boxes": len(b) if b is not None else None,
                "boxes_matching_v5": match(v5_boxes, b) if b is not None and v5_boxes is not None else None,
            }
        pages.append(page)

    rng = random.Random(20261110)
    summary = {}
    for kind in ("ground truth", "drafts"):
        sel = [p for p in pages if p["kind"] == kind]
        chars = sum(p["chars"] for p in sel)
        ci = bootstrap(sel, list(runs), rng)
        summary[kind] = {"pages": len(sel), "chars": chars, "sets": {}}
        for name in runs:
            edits = sum(p["sets"][name]["edits"] for p in sel)
            classes = {}
            for p in sel:
                for k, v in p["sets"][name]["errors_by_class"].items():
                    classes[k] = classes.get(k, 0) + v
            v5_boxes = sum(p["sets"][V5]["boxes"] or 0 for p in sel)
            summary[kind]["sets"][name] = {
                "edits": edits,
                "pooled_cer": edits / chars,
                **ci[name],
                "pages_worse_than_v5": sum(p["sets"][name]["edits"] > p["sets"][V5]["edits"] for p in sel),
                "pages_better_than_v5": sum(p["sets"][name]["edits"] < p["sets"][V5]["edits"] for p in sel),
                "line_count_error": sum(abs(p["sets"][name]["lines"] - p["ref_lines"]) for p in sel),
                "ref_lines": sum(p["ref_lines"] for p in sel),
                "v5_boxes": v5_boxes,
                "boxes": sum(p["sets"][name]["boxes"] or 0 for p in sel),
                "boxes_matching_v5": sum(p["sets"][name]["boxes_matching_v5"] or 0 for p in sel),
                "errors_by_class": dict(sorted(classes.items(), key=lambda x: -x[1])),
            }
    a.out.write_text(json.dumps({"pages": pages, "summary": summary}, indent=2))
    for kind, s in summary.items():
        print(f"== {kind}: {s['pages']} pages, {s['chars']} characters")
        for name, v in s["sets"].items():
            lo, hi = v["rate_95"]
            dlo, dhi = v["diff_vs_v5_95"]
            print(f"  {name:38s} {v['edits']:4d} edits  {v['pooled_cer']:.4f} [{lo:.4f}, {hi:.4f}]  "
                  f"vs v5 [{dlo:+.4f}, {dhi:+.4f}]  lines off {v['line_count_error']}/{v['ref_lines']}  "
                  f"boxes {v['boxes_matching_v5']}/{v['v5_boxes']} match v5  {v['errors_by_class']}")


if __name__ == "__main__":
    main()
