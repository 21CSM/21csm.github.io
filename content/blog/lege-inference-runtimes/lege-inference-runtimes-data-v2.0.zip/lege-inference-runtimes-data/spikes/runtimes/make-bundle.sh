#!/bin/sh
# REVIEW SPIKE: build the public data bundle for the inference-library report:
# every result file, the scripts and workflows that produced them, the decision
# rule, the spike write-ups and the report source. Lege's own source code is not
# included (the repository is private). Local machine paths in the
# result files are replaced with placeholders.
#
# Usage: make-bundle.sh OUT.zip
set -eu
out=$(cd "$(dirname "$1")" && pwd)/$(basename "$1")
root=$(cd "$(dirname "$0")/../.." && pwd)
stage=$(mktemp -d)
dest=$stage/lege-inference-runtimes-data
mkdir -p "$dest"
cd "$root"
for path in spikes/runtimes docs/spikes docs/reports/inference-runtimes \
            .github/workflows/spike-runtimes.yml .github/workflows/spike-ort-official.yml \
            .github/workflows/spike-v6.yml .github/workflows/spike-review.yml \
            tests/tools/cer.py tests/fixtures/reference/manifest.json \
            tests/fixtures/reference/ground-truth tests/fixtures/reference/ground-truth-drafts \
            scripts/fetch-ppocr-models.sh LICENSE-MIT LICENSE-APACHE; do
    [ -e "$path" ] || continue
    mkdir -p "$dest/$(dirname "$path")"
    cp -R "$path" "$dest/$path"
done
# Scrub local paths from text files.
find "$dest" -type f \( -name '*.json' -o -name '*.md' -o -name '*.txt' -o -name '*.log' \) -print0 |
    xargs -0 sed -i.bak -E \
        -e 's#/private/tmp/claude-[0-9]+/[^"/ ]+/[^"/ ]+/scratchpad#<scratch>#g' \
        -e 's#/Users/[^/"]+#~#g' \
        -e 's#/home/runner/work/[^/"]+/[^/"]+#<checkout>#g'
find "$dest" -name '*.bak' -delete
# (this script names the patterns itself, so it is skipped)
if grep -rIl --exclude=make-bundle.sh -e '/private/tmp/claude' -e '/Users/' "$dest" >/dev/null; then
    echo "unscrubbed local paths remain:" >&2
    grep -rIl --exclude=make-bundle.sh -e '/private/tmp/claude' -e '/Users/' "$dest" >&2
    exit 1
fi
cat > "$dest/README.md" <<'EOF'
# Data and code for "Choosing an inference library for Lege"

Everything behind the report's tables: the raw result files, the scripts and
GitHub Actions workflows that produced them, the decision rule as committed,
the spike write-ups, the report source (Typst), the reference transcriptions,
and the model-fetching script with its pinned hashes.

- `spikes/runtimes/results/`: result files. Version 1 files sit at the top;
  `v6/` holds the PP-OCRv6 runs; `review/` the runs made for version 2.
- `spikes/runtimes/*.py`, `*.sh`: the benchmark, checks and analysis scripts.
- `docs/spikes/`: decision rule and write-ups.
- `docs/reports/inference-runtimes/report.typ`: the report source.

Local paths in the result files are replaced by `<scratch>`, `~` and
`<checkout>`. Lege's source code is not public and is not included, so the
runs cannot be repeated from this archive alone; every number can be checked
against its result file, and every analysis rerun. Licence for the scripts:
MIT OR Apache-2.0.
EOF
rm -f "$out"
(cd "$stage" && zip -qr "$out" lege-inference-runtimes-data)
rm -rf "$stage"
echo "wrote $out ($(du -h "$out" | cut -f1))"
