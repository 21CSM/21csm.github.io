// SPIKE: print the x86 SIMD features this process sees. Run under
// `qemu-x86_64 -cpu <model>` to prove the emulated CPU really lacks AVX2 or AVX,
// since tract, RTen and ONNX Runtime all pick their kernels from the same CPUID.
// Build: rustc -O spikes/runtimes/cpu_features.rs -o cpu_features
fn main() {
    #[cfg(target_arch = "x86_64")]
    {
        let f = [
            ("sse4.2", std::is_x86_feature_detected!("sse4.2")),
            ("avx", std::is_x86_feature_detected!("avx")),
            ("fma", std::is_x86_feature_detected!("fma")),
            ("avx2", std::is_x86_feature_detected!("avx2")),
            ("avx512f", std::is_x86_feature_detected!("avx512f")),
        ];
        let line: Vec<String> = f.iter().map(|(n, on)| format!("{n}={}", if *on { "yes" } else { "no" })).collect();
        println!("{}", line.join(" "));
    }
    #[cfg(target_arch = "aarch64")]
    {
        let f = [
            ("neon", std::arch::is_aarch64_feature_detected!("neon")),
            ("dotprod", std::arch::is_aarch64_feature_detected!("dotprod")),
            ("fp16", std::arch::is_aarch64_feature_detected!("fp16")),
            ("i8mm", std::arch::is_aarch64_feature_detected!("i8mm")),
        ];
        let line: Vec<String> = f.iter().map(|(n, on)| format!("{n}={}", if *on { "yes" } else { "no" })).collect();
        println!("{}", line.join(" "));
    }
}
