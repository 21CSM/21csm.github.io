#!/usr/bin/env python3
"""MODEL SPIKE: write a PP-OCRv6 recognizer's character dictionary as dict.txt.

PP-OCRv6 ships its dictionary inside inference.yml (PostProcess.character_dict)
rather than as a separate file. This reads that list with the standard library
only (each entry is one YAML scalar on a `  - ` line, plain or quoted) and writes
one entry per line, LF-terminated, the format Lege's dict.txt expects.

Usage: v6_dict.py inference.yml dict.txt
"""
import sys


def scalar(s: str) -> str:
    if len(s) >= 2 and s[0] == s[-1] == "'":
        return s[1:-1].replace("''", "'")
    if len(s) >= 2 and s[0] == s[-1] == '"':
        return s[1:-1].encode("latin-1", "backslashreplace").decode("unicode_escape")
    return s


def main():
    lines = open(sys.argv[1], encoding="utf-8").read().split("\n")
    start = next(i for i, l in enumerate(lines) if l.strip() == "character_dict:")
    indent = None
    out = []
    for l in lines[start + 1:]:
        stripped = l.lstrip(" ")
        if not stripped.startswith("- "):
            break
        here = len(l) - len(stripped)
        indent = here if indent is None else indent
        if here != indent:
            break
        out.append(scalar(stripped[2:]))
    bad = [e for e in out if e == "" or "\n" in e or "\r" in e]
    if bad:
        sys.exit(f"unusable dictionary entries: {bad[:5]!r}")
    with open(sys.argv[2], "w", encoding="utf-8", newline="\n") as f:
        f.writelines(e + "\n" for e in out)
    print(f"{sys.argv[2]}: {len(out)} entries")


if __name__ == "__main__":
    main()
