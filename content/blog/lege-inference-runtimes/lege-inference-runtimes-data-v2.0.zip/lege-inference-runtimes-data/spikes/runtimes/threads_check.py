#!/usr/bin/env python3
"""Runtime spike: does output change with the thread count?

Runs each `lege` binary once per image at every thread count and compares the
ALTO bytes with the 1-thread run. Prints one line per binary and writes
threads.json. Timing is not measured, so this is valid on shared runners.

Usage:
  threads_check.py --models DIR --out DIR --bin NAME=PATH [--bin ...] [--threads 1,2,3,4,6,8]
"""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REF = ROOT / "tests" / "fixtures" / "reference"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--bin", action="append", default=[], help="name=path")
    ap.add_argument("--threads", default="1,2,3,4,6,8")
    a = ap.parse_args()
    threads = [int(t) for t in a.threads.split(",")]
    entries = json.loads((REF / "manifest.json").read_text())["entries"]
    report = {}
    for name, binary in (b.split("=", 1) for b in a.bin):
        mismatches, failures = [], []
        for e in entries:
            image = REF / e["file"]
            hashes = {}
            for t in threads:
                out = a.out / name / f"t{t}"
                out.mkdir(parents=True, exist_ok=True)
                p = subprocess.run([binary, "--models", str(a.models), "--out-dir", str(out),
                                    "--threads", str(t), "--output", "alto", str(image)],
                                   capture_output=True, text=True)
                if p.returncode != 0:
                    failures.append({"image": e["id"], "threads": t, "stderr": p.stderr.strip()[-300:]})
                    continue
                alto = (out / f"{image.stem}.alto.xml").read_bytes()
                hashes[t] = hashlib.sha256(alto).hexdigest()[:12]
            base = hashes.get(threads[0])
            differ = [t for t, h in hashes.items() if h != base]
            if differ:
                mismatches.append({"image": e["id"], "differs_at": differ, "hashes": hashes})
        report[name] = {"threads": threads, "images": len(entries), "mismatches": mismatches, "failures": failures}
        verdict = "same at every thread count" if not mismatches else \
            "; ".join(f"{m['image']} differs at {m['differs_at']}" for m in mismatches)
        print(f"{name}: {len(entries)} images x threads {a.threads}: {verdict}"
              + (f" ({len(failures)} failed runs)" if failures else ""), flush=True)
    a.out.mkdir(parents=True, exist_ok=True)
    (a.out / "threads.json").write_text(json.dumps(report, indent=2))
    sys.exit(0)


if __name__ == "__main__":
    main()
