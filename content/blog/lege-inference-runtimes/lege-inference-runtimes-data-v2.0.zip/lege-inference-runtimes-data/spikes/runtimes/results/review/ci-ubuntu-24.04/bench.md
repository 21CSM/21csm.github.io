## Linux x86-64 (GitHub runner), official ONNX Runtime, built with rustup

CPU: AMD EPYC 9V74 80-Core Processor (x86_64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 126.7 s (126.1–128.2) | 118.2 s (117.7–119.2) | 0.0016 (5 pages) | 0.38 GB | 25/25 | 25/25 exact, 25/25 within tolerance | yes | 0 |
| tract-lto | 125.2 s (124.5–126.1) | 115.8 s (115.3–116.5) | 0.0016 (5 pages) | 0.38 GB | 25/25 | 25/25 exact, 25/25 within tolerance | yes | 0 |
| rten | 99.6 s (99.0–101.4) | 95.0 s (94.7–96.0) | 0.0016 (5 pages) | 0.41 GB | 25/25 | 23/25 exact, 23/25 within tolerance | yes | 0 |
| rten-lto | 100.2 s (99.7–101.6) | 94.9 s (94.5–95.6) | 0.0016 (5 pages) | 0.41 GB | 25/25 | 23/25 exact, 23/25 within tolerance | yes | 0 |
| rten-prepack | 99.6 s (99.0–101.5) | 94.8 s (94.6–95.6) | 0.0016 (5 pages) | 0.41 GB | 25/25 | 23/25 exact, 23/25 within tolerance | yes | 0 |
| ort | 55.4 s (55.0–56.9) | 55.3 s (55.1–55.7) | 0.0016 (5 pages) | 0.51 GB | 25/25 | 24/25 exact, 24/25 within tolerance | yes | 0 |
| ort-lto | 55.3 s (54.9–56.8) | 55.3 s (55.1–56.1) | 0.0016 (5 pages) | 0.51 GB | 25/25 | 24/25 exact, 24/25 within tolerance | yes | 0 |
| ort-lines | 55.4 s (55.0–56.5) | 54.0 s (53.7–55.4) | 0.0016 (5 pages) | 0.56 GB | 25/25 | 24/25 exact, 24/25 within tolerance | yes | 0 |
