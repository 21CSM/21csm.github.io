## Linux ARM64 (GitHub runner), PP-OCRv6 small

CPU:  (aarch64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 183.5 s (182.4–184.8) | 110.8 s (110.1–111.6) | 0.0024 (5 pages) | 0.71 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 148.6 s (148.0–149.0) | 82.2 s (81.9–82.8) | 0.0024 (5 pages) | 0.46 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 137.2 s (136.8–137.6) | 76.4 s (76.2–76.9) | 0.0024 (5 pages) | 0.55 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
