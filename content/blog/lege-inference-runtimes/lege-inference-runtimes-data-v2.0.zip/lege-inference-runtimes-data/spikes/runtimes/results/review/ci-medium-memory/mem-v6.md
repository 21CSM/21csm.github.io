## Linux x86-64, PP-OCRv6 medium (v6)

CPU: AMD EPYC 9V74 80-Core Processor (x86_64, 2 logical cores)
1 run(s), no warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 548.5 s (548.5–548.5) | 0.0032 (5 pages) | 2.65 GB | 5/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 439.2 s (439.2–439.2) | 0.0032 (5 pages) | 1.24 GB | 5/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 285.6 s (285.6–285.6) | 0.0032 (5 pages) | 1.43 GB | 5/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| tract-bucket32 | 540.0 s (540.0–540.0) | 0.0032 (5 pages) | 1.62 GB | 5/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
