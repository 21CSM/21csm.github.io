## Linux x86-64 (GitHub runner), PP-OCRv6 tiny detector + PP-OCRv5 Latin recognizer

CPU: Intel(R) Xeon(R) 6975P-C (x86_64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 82.2 s (81.9–82.6) | 79.5 s (79.3–79.8) | 0.0297 (5 pages) | 0.44 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 89.5 s (89.2–89.8) | 85.9 s (85.7–86.1) | 0.0297 (5 pages) | 0.33 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 50.6 s (50.5–50.9) | 50.7 s (50.6–50.8) | 0.0297 (5 pages) | 0.36 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
