## Linux ARM64 (GitHub runner), official ONNX Runtime, built with rustup

CPU: aarch64 (aarch64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 149.6 s (148.8–150.6) | 104.1 s (103.7–104.5) | 0.0016 (5 pages) | 0.38 GB | 25/25 | 22/25 exact, 25/25 within tolerance | yes | 0 |
| tract-lto | 147.3 s (146.5–148.0) | 101.6 s (101.3–102.1) | 0.0016 (5 pages) | 0.37 GB | 25/25 | 22/25 exact, 25/25 within tolerance | yes | 0 |
| rten | 115.5 s (115.3–115.9) | 70.6 s (70.4–70.8) | 0.0016 (5 pages) | 0.41 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| rten-lto | 115.6 s (115.2–115.9) | 70.4 s (70.3–70.6) | 0.0016 (5 pages) | 0.41 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| rten-prepack | 115.5 s (115.3–115.8) | 70.6 s (70.4–70.9) | 0.0016 (5 pages) | 0.41 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| ort | 99.3 s (99.0–99.7) | 59.4 s (59.2–59.7) | 0.0016 (5 pages) | 0.51 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| ort-lto | 99.3 s (99.1–99.7) | 59.4 s (59.2–59.8) | 0.0016 (5 pages) | 0.50 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| ort-lines | 99.4 s (99.1–99.8) | 68.8 s (68.6–69.2) | 0.0016 (5 pages) | 0.54 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
