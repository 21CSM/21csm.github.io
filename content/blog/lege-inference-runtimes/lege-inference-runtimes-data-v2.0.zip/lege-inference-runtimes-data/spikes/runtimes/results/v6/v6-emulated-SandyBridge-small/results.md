## Emulated SandyBridge, PP-OCRv6 small

CPU: AMD EPYC 9V74 80-Core Processor (x86_64, 2 logical cores), run under `qemu-x86_64 -cpu SandyBridge`
1 run(s), no warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 1410.0 s (1410.0–1410.0) | 0.0000 (1 pages) | 0.70 GB | 1/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| rten | 1401.6 s (1401.6–1401.6) | 0.0000 (1 pages) | 0.47 GB | 1/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| ort | 1147.3 s (1147.3–1147.3) | 0.0000 (1 pages) | 0.59 GB | 1/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
