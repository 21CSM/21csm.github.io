## Linux x86-64 (GitHub runner), PP-OCRv6 small detector + PP-OCRv5 Latin recognizer

CPU: AMD EPYC 7763 64-Core Processor (x86_64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 140.0 s (139.5–141.0) | 129.7 s (128.9–130.4) | 0.0016 (5 pages) | 0.36 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 121.8 s (121.5–122.4) | 119.9 s (119.7–120.5) | 0.0016 (5 pages) | 0.43 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 68.2 s (68.1–68.9) | 67.3 s (67.2–67.7) | 0.0016 (5 pages) | 0.50 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
