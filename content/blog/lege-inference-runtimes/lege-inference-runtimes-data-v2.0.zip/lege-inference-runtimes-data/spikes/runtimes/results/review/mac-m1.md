## Mac M3 Pro, review: builds, tuning, threading

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 51.8 s (50.8–52.7) | 38.0 s (37.1–40.1) | 0.0016 (5 pages) | 1.06 GB | 25/25 | 22/25 exact, 25/25 within tolerance | yes | 0 |
| tract-lto | 50.7 s (49.9–51.5) | 37.0 s (36.1–37.9) | 0.0016 (5 pages) | 1.05 GB | 25/25 | 22/25 exact, 25/25 within tolerance | yes | 0 |
| tract-lines | 51.8 s (51.0–52.6) | 30.1 s (29.6–30.8) | 0.0016 (5 pages) | 1.08 GB | 25/25 | 22/25 exact, 25/25 within tolerance | yes | 0 |
| tract-bucket32 | 45.3 s (44.5–46.0) | 31.4 s (30.5–33.3) | 0.0016 (5 pages) | 0.78 GB | 18/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 58.2 s (57.4–59.1) | 23.5 s (23.2–23.8) | 0.0016 (5 pages) | 0.46 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| rten-lto | 58.3 s (57.5–59.6) | 23.5 s (23.1–24.1) | 0.0016 (5 pages) | 0.46 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| rten-prepack | 58.1 s (57.4–59.7) | 23.5 s (23.1–24.1) | 0.0016 (5 pages) | 0.46 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| rten-lines | 58.2 s (57.5–59.3) | 30.2 s (29.4–31.3) | 0.0016 (5 pages) | 0.51 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| ort | 55.1 s (54.5–56.2) | 22.4 s (22.1–23.2) | 0.0016 (5 pages) | 0.55 GB | 25/25 | 24/25 exact, 25/25 within tolerance | no (pd-aurelius-meditations-1887-n100-rot180) | 0 |
| ort-lto | 54.9 s (54.5–56.2) | 22.3 s (22.0–22.9) | 0.0016 (5 pages) | 0.55 GB | 25/25 | 24/25 exact, 25/25 within tolerance | no (pd-aurelius-meditations-1887-n100-rot180) | 0 |
| ort-nomempattern | 55.1 s (54.4–55.9) | 22.3 s (22.0–22.9) | 0.0016 (5 pages) | 0.55 GB | 25/25 | 24/25 exact, 25/25 within tolerance | no (pd-aurelius-meditations-1887-n100-rot180) | 0 |
| ort-optcache | — | — | — | 0.00 GB | 0/25 | 0/25 exact, 0/25 within tolerance | yes | 50 |
| ort-spin | 55.1 s (54.3–56.4) | 20.3 s (20.0–20.7) | 0.0016 (5 pages) | 0.55 GB | 25/25 | 24/25 exact, 25/25 within tolerance | no (pd-aurelius-meditations-1887-n100-rot180) | 0 |
| ort-lines | 54.9 s (54.4–56.2) | 30.0 s (29.7–30.5) | 0.0016 (5 pages) | 0.66 GB | 25/25 | 24/25 exact, 25/25 within tolerance | yes | 0 |
| ort-official | 55.0 s (54.2–55.9) | 22.3 s (21.7–24.1) | 0.0016 (5 pages) | 0.56 GB | 25/25 | 24/25 exact, 25/25 within tolerance | yes | 0 |
| ort-official-lines | 54.7 s (54.3–55.7) | 29.7 s (29.2–30.5) | 0.0016 (5 pages) | 0.67 GB | 25/25 | 24/25 exact, 25/25 within tolerance | yes | 0 |
