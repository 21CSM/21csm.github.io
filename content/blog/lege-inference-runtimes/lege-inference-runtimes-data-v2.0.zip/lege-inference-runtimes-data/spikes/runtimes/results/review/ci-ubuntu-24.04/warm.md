## Linux x86-64 (GitHub runner), after reading another page

CPU: AMD EPYC 9V74 80-Core Processor (x86_64, 2 logical cores)
Median of 1 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 119.4 s (119.4–119.4) | 0.0016 (5 pages) | 0.58 GB | 25/25 | 25/25 exact, 25/25 within tolerance | yes | 0 |
| rten | 98.2 s (98.2–98.2) | 0.0016 (5 pages) | 0.43 GB | 25/25 | 23/25 exact, 23/25 within tolerance | yes | 0 |
| ort | 48.9 s (48.9–48.9) | 0.0016 (5 pages) | 0.86 GB | 25/25 | 24/25 exact, 24/25 within tolerance | yes | 0 |
