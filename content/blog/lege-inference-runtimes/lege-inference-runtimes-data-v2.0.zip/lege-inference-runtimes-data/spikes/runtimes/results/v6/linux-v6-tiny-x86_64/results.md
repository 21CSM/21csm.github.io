## Linux x86-64 (GitHub runner), PP-OCRv6 tiny

CPU: AMD EPYC 9V74 80-Core Processor (x86_64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 59.9 s (59.3–60.8) | 54.2 s (53.8–55.3) | 0.0347 (5 pages) | 0.28 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 42.4 s (41.9–43.1) | 38.4 s (38.1–38.9) | 0.0347 (5 pages) | 0.31 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 23.6 s (23.4–24.4) | 23.2 s (23.0–24.0) | 0.0347 (5 pages) | 0.35 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
