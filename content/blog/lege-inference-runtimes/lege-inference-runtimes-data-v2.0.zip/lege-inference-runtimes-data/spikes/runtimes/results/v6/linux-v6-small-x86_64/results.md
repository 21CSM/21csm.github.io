## Linux x86-64 (GitHub runner), PP-OCRv6 small

CPU: AMD EPYC 7763 64-Core Processor (x86_64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 149.2 s (148.3–150.1) | 138.1 s (137.4–138.6) | 0.0024 (5 pages) | 0.73 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 117.8 s (117.4–118.6) | 111.9 s (111.5–112.5) | 0.0024 (5 pages) | 0.46 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 77.7 s (77.4–78.4) | 75.4 s (75.1–76.1) | 0.0024 (5 pages) | 0.55 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
