## Mac M3 Pro, PP-OCRv6 small detector + PP-OCRv5 Latin recognizer

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 53.7 s (53.5–53.9) | 32.8 s (32.7–32.9) | 0.0016 (5 pages) | 1.15 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 59.3 s (59.3–59.4) | 22.1 s (22.0–22.1) | 0.0016 (5 pages) | 0.50 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 54.8 s (54.8–54.9) | 20.2 s (20.2–20.3) | 0.0016 (5 pages) | 0.56 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
