## Linux ARM64 (GitHub runner), after reading another page

CPU: aarch64 (aarch64, 2 logical cores)
Median of 1 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 139.1 s (139.1–139.1) | 0.0016 (5 pages) | 0.56 GB | 25/25 | 22/25 exact, 25/25 within tolerance | yes | 0 |
| rten | 114.8 s (114.8–114.8) | 0.0016 (5 pages) | 0.43 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| ort | 94.2 s (94.2–94.2) | 0.0016 (5 pages) | 0.85 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
