## Linux ARM64 (GitHub runner), PP-OCRv6 small detector + PP-OCRv5 Latin recognizer

CPU:  (aarch64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 151.7 s (150.5–153.2) | 96.9 s (96.5–97.4) | 0.0016 (5 pages) | 0.35 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 123.5 s (123.0–124.1) | 71.9 s (71.7–72.1) | 0.0016 (5 pages) | 0.44 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 106.1 s (105.7–106.7) | 60.2 s (60.1–60.4) | 0.0016 (5 pages) | 0.50 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
