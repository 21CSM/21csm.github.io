## Mac M3 Pro, PP-OCRv6 medium

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 171.8 s (169.4–174.7) | 86.1 s (85.1–86.9) | 0.0032 (5 pages) | 4.63 GB | 5/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 340.8 s (334.3–346.2) | 94.3 s (93.0–96.1) | 0.0032 (5 pages) | 1.47 GB | 5/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 330.7 s (321.5–334.6) | 91.0 s (90.6–93.9) | 0.0032 (5 pages) | 1.62 GB | 5/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
