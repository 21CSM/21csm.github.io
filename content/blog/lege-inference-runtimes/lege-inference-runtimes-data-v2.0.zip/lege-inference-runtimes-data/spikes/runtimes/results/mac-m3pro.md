## Mac M3 Pro (after the tract fix)

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 47.5 s (47.3–48.4) | 35.4 s (34.7–36.0) | 0.0016 (5 pages) | 1.06 GB | 25/25 | 22/25 exact, 25/25 within tolerance | yes | 0 |
| rten | 53.7 s (53.4–54.1) | 21.7 s (21.6–21.8) | 0.0016 (5 pages) | 0.46 GB | 25/25 | 23/25 exact, 25/25 within tolerance | yes | 0 |
| ort | 50.8 s (50.5–51.4) | 20.5 s (20.5–20.5) | 0.0016 (5 pages) | 0.58 GB | 25/25 | 24/25 exact, 25/25 within tolerance | no (pd-aurelius-meditations-1887-n100-rot180) | 0 |
