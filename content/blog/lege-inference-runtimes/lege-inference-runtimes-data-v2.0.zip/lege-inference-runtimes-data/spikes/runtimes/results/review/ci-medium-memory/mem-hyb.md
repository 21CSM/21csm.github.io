## Linux x86-64, PP-OCRv6 medium (hyb)

CPU: AMD EPYC 9V74 80-Core Processor (x86_64, 2 logical cores)
1 run(s), no warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 346.3 s (346.3–346.3) | 0.0016 (5 pages) | 1.18 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 274.8 s (274.8–274.8) | 0.0016 (5 pages) | 1.15 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 132.1 s (132.1–132.1) | 0.0016 (5 pages) | 1.26 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| tract-bucket32 | 335.6 s (335.6–335.6) | 0.0016 (5 pages) | 1.17 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
