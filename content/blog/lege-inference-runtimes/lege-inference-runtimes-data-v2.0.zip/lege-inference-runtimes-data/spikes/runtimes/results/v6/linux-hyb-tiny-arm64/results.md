## Linux ARM64 (GitHub runner), PP-OCRv6 tiny detector + PP-OCRv5 Latin recognizer

CPU:  (aarch64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 130.8 s (130.1–131.4) | 88.2 s (88.0–88.6) | 0.0297 (5 pages) | 0.44 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 106.9 s (106.8–107.2) | 64.2 s (64.1–64.4) | 0.0297 (5 pages) | 0.33 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 92.3 s (92.1–92.5) | 54.0 s (53.9–54.2) | 0.0297 (5 pages) | 0.35 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
