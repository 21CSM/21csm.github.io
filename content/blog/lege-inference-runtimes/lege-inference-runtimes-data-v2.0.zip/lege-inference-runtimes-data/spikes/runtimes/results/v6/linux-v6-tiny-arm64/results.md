## Linux ARM64 (GitHub runner), PP-OCRv6 tiny

CPU:  (aarch64, 2 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 2 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 61.9 s (61.6–62.3) | 42.8 s (42.6–43.1) | 0.0347 (5 pages) | 0.26 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 47.5 s (47.5–47.7) | 28.8 s (28.8–29.0) | 0.0347 (5 pages) | 0.31 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 43.2 s (43.1–43.3) | 26.7 s (26.6–26.9) | 0.0347 (5 pages) | 0.35 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
