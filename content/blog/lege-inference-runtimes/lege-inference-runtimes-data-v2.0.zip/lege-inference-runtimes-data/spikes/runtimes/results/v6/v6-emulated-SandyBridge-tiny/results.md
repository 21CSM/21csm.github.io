## Emulated SandyBridge, PP-OCRv6 tiny

CPU: AMD EPYC 7763 64-Core Processor (x86_64, 2 logical cores), run under `qemu-x86_64 -cpu SandyBridge`
1 run(s), no warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 1558.9 s (1558.9–1558.9) | 0.1491 (1 pages) | 0.40 GB | 0/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| rten | 823.9 s (823.9–823.9) | 0.1491 (1 pages) | 0.32 GB | 0/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| ort | 1327.5 s (1327.5–1327.5) | 0.1491 (1 pages) | 0.39 GB | 0/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
