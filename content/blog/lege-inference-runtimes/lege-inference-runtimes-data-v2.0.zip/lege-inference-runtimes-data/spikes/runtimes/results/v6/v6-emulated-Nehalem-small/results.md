## Emulated Nehalem, PP-OCRv6 small

CPU: AMD EPYC 7763 64-Core Processor (x86_64, 2 logical cores), run under `qemu-x86_64 -cpu Nehalem`
1 run(s), no warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 1621.0 s (1621.0–1621.0) | 0.0000 (1 pages) | 0.71 GB | 1/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| rten | 1574.4 s (1574.4–1574.4) | 0.0000 (1 pages) | 0.47 GB | 1/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| ort | 1531.8 s (1531.8–1531.8) | 0.0000 (1 pages) | 0.59 GB | 1/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
