## Mac M3 Pro, PP-OCRv6 medium detector + PP-OCRv5 Latin recognizer

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 113.3 s (113.0–113.6) | 57.0 s (56.9–57.2) | 0.0016 (5 pages) | 2.50 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 155.7 s (155.6–155.9) | 48.7 s (48.6–48.7) | 0.0016 (5 pages) | 1.27 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 140.8 s (140.7–140.9) | 43.8 s (43.8–43.9) | 0.0016 (5 pages) | 1.39 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
