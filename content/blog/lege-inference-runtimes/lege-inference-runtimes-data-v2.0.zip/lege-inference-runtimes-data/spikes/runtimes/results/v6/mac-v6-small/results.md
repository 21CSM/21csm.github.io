## Mac M3 Pro, PP-OCRv6 small

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 63.6 s (62.4–66.1) | 36.2 s (35.5–37.2) | 0.0024 (5 pages) | 1.48 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 70.8 s (69.5–71.6) | 24.4 s (24.2–25.2) | 0.0024 (5 pages) | 0.56 GB | 7/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 68.2 s (67.0–69.6) | 24.5 s (24.2–25.2) | 0.0024 (5 pages) | 0.69 GB | 7/25 | 0/25 exact, 0/25 within tolerance | no (pd-mickiewicz-pisma-1877-n120, pd-stevenson-treasure-1907-n120, pd-walden-1893-n150-flip, pd-walden-1893-n150-flip.tiff-raw) | 0 |
