## Mac M3 Pro, PP-OCRv6 tiny detector + PP-OCRv5 Latin recognizer

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 46.5 s (46.3–46.8) | 32.0 s (31.4–33.1) | 0.0297 (5 pages) | 1.04 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 52.7 s (52.6–53.0) | 20.7 s (20.7–20.8) | 0.0297 (5 pages) | 0.36 GB | 6/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 49.2 s (49.1–49.4) | 19.2 s (19.1–19.2) | 0.0297 (5 pages) | 0.42 GB | 6/25 | 0/25 exact, 0/25 within tolerance | no (pd-aurelius-meditations-1887-n100-rot180) | 0 |
