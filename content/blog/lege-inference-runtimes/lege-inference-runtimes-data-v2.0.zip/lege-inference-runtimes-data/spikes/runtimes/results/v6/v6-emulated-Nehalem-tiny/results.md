## Emulated Nehalem, PP-OCRv6 tiny

CPU: AMD EPYC 9V74 80-Core Processor (x86_64, 2 logical cores), run under `qemu-x86_64 -cpu Nehalem`
1 run(s), no warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|
| tract | 819.2 s (819.2–819.2) | 0.1491 (1 pages) | 0.40 GB | 0/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| rten | 708.9 s (708.9–708.9) | 0.1491 (1 pages) | 0.32 GB | 0/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
| ort | 662.1 s (662.1–662.1) | 0.1491 (1 pages) | 0.39 GB | 0/3 | 0/3 exact, 0/3 within tolerance | yes | 0 |
