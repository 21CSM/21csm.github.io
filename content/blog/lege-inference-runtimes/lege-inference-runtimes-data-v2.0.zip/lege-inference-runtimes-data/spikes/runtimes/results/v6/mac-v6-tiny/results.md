## Mac M3 Pro, PP-OCRv6 tiny

CPU: Apple M3 Pro (arm64, 11 logical cores)
Median of 3 runs after a warm-up. Snapshot platform: linux-x86_64.

| Runtime | Total, 1 thr (fastest–slowest run) | Total, 4 thr (fastest–slowest run) | Mean CER | Peak memory | Text = snapshot | ALTO = snapshot | Same at any thread count | Failures |
|---|---|---|---|---|---|---|---|---|
| tract | 26.9 s (26.3–27.8) | 18.6 s (17.9–20.0) | 0.0347 (5 pages) | 0.71 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| rten | 23.1 s (22.8–23.6) | 10.3 s (9.9–10.9) | 0.0347 (5 pages) | 0.35 GB | 3/25 | 0/25 exact, 0/25 within tolerance | yes | 0 |
| ort | 22.1 s (21.7–22.7) | 10.7 s (10.4–11.3) | 0.0347 (5 pages) | 0.42 GB | 3/25 | 0/25 exact, 0/25 within tolerance | no (pd-aurelius-meditations-1887-n100-rot180) | 0 |
