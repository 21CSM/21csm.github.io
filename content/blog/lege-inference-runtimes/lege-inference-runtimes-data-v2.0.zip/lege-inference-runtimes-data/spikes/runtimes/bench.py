#!/usr/bin/env python3
"""Runtime spike: run the real `lege` CLI, built against tract, RTen and ONNX
Runtime, over the reference set, and compare speed, memory, output and
determinism.

Each binary is the same Lege code; only the inference library differs
(crates/lege-ppocr/src/runtime_alt.rs on branch spike/runtimes).

Usage:
  bench.py --models DIR --out DIR [--bin tract=PATH] [--bin rten=PATH] [--bin ort=PATH]
           [--threads 1,4] [--repeats 3] [--images ID,ID,...] [--wrapper "qemu-x86_64 -cpu SandyBridge"]
           [--label NAME] [--env NAME:KEY=VALUE ...] [--warm-with IMAGE_ID]

For every (runtime, threads) it runs each image once to warm up, then
`--repeats` times, and records:
  * page time: median of the repeats, from `lege --timing` (decode + recognize + write);
  * model load time, median;
  * peak memory (max RSS over the repeats), from /usr/bin/time;
  * whether ALTO and text match the approved snapshot (byte for byte, or with the
    WC tolerance the acceptance tests allow off the snapshot platform);
  * whether output is identical across repeats and across thread counts;
  * CER against ground truth where the manifest has it.
Writes results.json and results.md into --out.

Review additions (branch spike/review):
  * every run's page time, end-to-end process time (wall) and peak heap (when the
    binary is built with the `heap-stats` feature) are kept in "runs";
  * --env NAME:KEY=VALUE sets an environment variable for one binary only, so
    variants of one build (for example per-line threading) can take turns;
  * --warm-with IMAGE_ID reads that image first in the same process, untimed
    (LEGE_SPIKE_WARM_WITH), so the page time excludes one-off setup.
"""
import argparse
import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests" / "tools"))
from cer import cer  # noqa: E402
from snapshot_reference import alto_matches_snapshot, platform_id  # noqa: E402

REF = ROOT / "tests" / "fixtures" / "reference"
TIMING = re.compile(r"(\w+)=([0-9.]+)ms")
HEAP = re.compile(r"lege-spike: heap-peak=(\d+)")


def peak_rss_args():
    if sys.platform == "darwin":
        return ["/usr/bin/time", "-l"]  # BSD time
    gnu = shutil.which("time") or "/usr/bin/time"  # GNU time (the spike's Nix shell has it)
    return [gnu, "-v"]


def parse_rss(stderr: str) -> int | None:
    m = re.search(r"(\d+)\s+maximum resident set size", stderr)  # macOS: bytes
    if m:
        return int(m.group(1))
    m = re.search(r"Maximum resident set size \(kbytes\):\s*(\d+)", stderr)  # GNU: KiB
    if m:
        return int(m.group(1)) * 1024
    return None


def run_once(binary, wrapper, models, image, out_dir, threads, env=None):
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = peak_rss_args() + wrapper + [binary, "--models", str(models), "--out-dir", str(out_dir),
                                       "--threads", str(threads), "--timing", str(image)]
    start = time.monotonic()
    p = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, **(env or {})})
    wall = time.monotonic() - start
    timing = dict((k, float(v)) for k, v in TIMING.findall(p.stderr))
    stem = image.stem
    alto = (out_dir / f"{stem}.alto.xml").read_bytes() if p.returncode == 0 else b""
    txt = (out_dir / f"{stem}.txt").read_bytes() if p.returncode == 0 else b""
    errors = [l for l in p.stderr.splitlines() if l.startswith("lege: error")]
    return {
        "exit": p.returncode,
        "error": errors[0] if errors else None,
        "page_ms": timing.get("page"),
        "load_ms": timing.get("load"),
        "wall_s": wall,
        "rss": parse_rss(p.stderr),
        "heap": int(m.group(1)) if (m := HEAP.search(p.stderr)) else None,
        "alto_sha": hashlib.sha256(alto).hexdigest(),
        "alto": alto,
        "txt": txt,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--bin", action="append", default=[], help="name=path")
    ap.add_argument("--threads", default="1,4")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--images", default="")
    ap.add_argument("--wrapper", default="", help="command prefix, e.g. an emulator")
    ap.add_argument("--label", default="")
    ap.add_argument("--no-warmup", action="store_true", help="skip the warm-up run (for slow emulated runs)")
    ap.add_argument("--env", action="append", default=[], help="NAME:KEY=VALUE, for one binary")
    ap.add_argument("--warm-with", default="", help="image id read first, untimed, in each process")
    a = ap.parse_args()

    manifest = json.loads((REF / "manifest.json").read_text())
    snapshot_platform = manifest.get("snapshot_platform")
    same_platform = snapshot_platform == platform_id() and not a.wrapper
    entries = manifest["entries"]
    if a.images:
        wanted = a.images.split(",")
        entries = [e for e in entries if e["id"] in wanted]
    bins = dict(b.split("=", 1) for b in a.bin)
    envs = {name: {} for name in bins}
    for spec in a.env:
        name, kv = spec.split(":", 1)
        key, value = kv.split("=", 1)
        envs[name][key] = value
    if a.warm_with:
        warm = next(e for e in manifest["entries"] if e["id"] == a.warm_with)
        for name in bins:
            envs[name]["LEGE_SPIKE_WARM_WITH"] = str(REF / warm["file"])
    threads = [int(t) for t in a.threads.split(",")]
    wrapper = shlex.split(a.wrapper)
    a.out.mkdir(parents=True, exist_ok=True)

    results = {
        "label": a.label or platform_id(),
        "platform": platform_id(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "cpu": cpu_name(),
        "wrapper": a.wrapper,
        "snapshot_platform": snapshot_platform,
        "repeats": a.repeats,
        "warmup": not a.no_warmup,
        "warm_with": a.warm_with or None,
        "envs": envs,
        "runtimes": {},
    }
    # Libraries take turns image by image (and repeat by repeat), so a slowdown
    # partway through, from a busy neighbour or heat, hits all of them alike.
    rts = {name: {"threads": {}, "failures": []} for name in bins}
    hashes_by = {name: {} for name in bins}
    for t in threads:
        for name in bins:
            rts[name]["threads"][t] = {}
        for e in entries:
            image = REF / e["file"]
            stem = Path(e["file"]).stem
            runs = {name: [] for name in bins}
            failed = set()
            first = 1 if a.no_warmup else 0
            for rep in range(first, a.repeats + 1):
                for name, binary in bins.items():
                    if name in failed:
                        continue
                    r = run_once(binary, wrapper, a.models, image, a.out / name / f"t{t}" / f"r{rep}", t, envs[name])
                    if r["exit"] != 0:
                        rts[name]["failures"].append({"image": e["id"], "threads": t, "error": r["error"]})
                        failed.add(name)
                        continue
                    if rep > 0:  # rep 0 is the warm-up, unless --no-warmup
                        runs[name].append(r)
            exp_alto = (REF / "expected" / f"{stem}.alto.xml").read_bytes()
            exp_txt = (REF / "expected" / f"{stem}.txt").read_bytes()
            gt = e.get("ground_truth")
            for name in bins:
                rr = runs[name]
                if not rr:
                    rts[name]["threads"][t][e["id"]] = {"failed": True}
                    continue
                last = rr[-1]
                why = alto_matches_snapshot(last["alto"], exp_alto, same_platform)
                hs = {r["alto_sha"] for r in rr}
                hashes_by[name].setdefault(e["id"], set()).update(hs)
                pages = [r["page_ms"] for r in rr]
                rts[name]["threads"][t][e["id"]] = {
                    "page_ms": statistics.median(pages),
                    "page_ms_min": min(pages),
                    "page_ms_max": max(pages),
                    "load_ms": statistics.median(r["load_ms"] for r in rr),
                    "rss": max((r["rss"] or 0) for r in rr),
                    "heap": max((r["heap"] or 0) for r in rr) or None,
                    "wall_s": statistics.median(r["wall_s"] for r in rr),
                    "runs": [{"page_ms": r["page_ms"], "wall_s": r["wall_s"], "rss": r["rss"], "heap": r["heap"]} for r in rr],
                    "alto_identical": last["alto"] == exp_alto,
                    "alto_matches_snapshot": why is None,
                    "mismatch": why,
                    "text_identical": last["txt"] == exp_txt,
                    "repeatable": len(hs) == 1,
                    "cer": cer((REF / gt).read_text(), last["txt"].decode()) if gt else None,
                    "lines": last["txt"].count(b"\n"),
                    "expected_lines": exp_txt.count(b"\n"),
                }
                v = rts[name]["threads"][t][e["id"]]
                print(f"{name} t{t} {e['id']}: {v['page_ms']:.0f} ms text={'=' if v['text_identical'] else '≠'} "
                      f"alto={'=' if v['alto_identical'] else ('≈' if v['alto_matches_snapshot'] else '≠')}", flush=True)
    for name in bins:
        rts[name]["deterministic_across_threads"] = all(len(h) == 1 for h in hashes_by[name].values())
        rts[name]["nondeterministic_images"] = sorted(i for i, h in hashes_by[name].items() if len(h) != 1)
    results["runtimes"] = rts
    results["cores"] = os.cpu_count()

    (a.out / "results.json").write_text(json.dumps(results, indent=2, default=str))
    (a.out / "results.md").write_text(summary(results, threads))
    print(summary(results, threads))


def cpu_name():
    try:
        if sys.platform == "darwin":
            return subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True).stdout.strip()
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("model name"):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor()


def summary(results, threads):
    out = [f"## {results['label']}", "",
           f"CPU: {results['cpu']} ({results['machine']}, {results.get('cores')} logical cores)" + (f", run under `{results['wrapper']}`" if results["wrapper"] else ""),
           (f"Median of {results['repeats']} runs after a warm-up." if results["warmup"] else f"{results['repeats']} run(s), no warm-up.")
           + f" Snapshot platform: {results['snapshot_platform']}.", ""]
    head = ["Runtime"] + [f"Total, {t} thr (fastest–slowest run)" for t in threads] + ["Mean CER", "Peak memory", "Text = snapshot", "ALTO = snapshot", "Same at any thread count", "Failures"]
    out.append("| " + " | ".join(head) + " |")
    out.append("|" + "---|" * len(head))
    for name, rt in results["runtimes"].items():
        cells = [name]
        n_images = 0
        for t in threads:
            imgs = [v for v in rt["threads"].get(t, {}).values() if not v.get("failed")]
            n_images = max(n_images, len(rt["threads"].get(t, {})))
            cells.append(f"{sum(v['page_ms'] for v in imgs)/1000:.1f} s ({sum(v['page_ms_min'] for v in imgs)/1000:.1f}–{sum(v['page_ms_max'] for v in imgs)/1000:.1f})" if imgs else "—")
        imgs = [v for d in rt["threads"].values() for v in d.values() if not v.get("failed")]
        t0 = [v for v in rt["threads"].get(threads[0], {}).values() if not v.get("failed")]
        cers = [v["cer"] for v in t0 if v.get("cer") is not None]
        cells.append(f"{statistics.mean(cers):.4f} ({len(cers)} pages)" if cers else "—")
        cells.append(f"{max((v['rss'] for v in imgs), default=0)/2**30:.2f} GiB")
        cells.append(f"{sum(v['text_identical'] for v in t0)}/{n_images}")
        cells.append(f"{sum(v['alto_identical'] for v in t0)}/{n_images} exact, {sum(v['alto_matches_snapshot'] for v in t0)}/{n_images} within tolerance")
        cells.append("yes" if rt["deterministic_across_threads"] else f"no ({', '.join(rt['nondeterministic_images'])})")
        cells.append(str(len(rt["failures"])))
        out.append("| " + " | ".join(cells) + " |")
    out.append("")
    return "\n".join(out)


if __name__ == "__main__":
    main()
