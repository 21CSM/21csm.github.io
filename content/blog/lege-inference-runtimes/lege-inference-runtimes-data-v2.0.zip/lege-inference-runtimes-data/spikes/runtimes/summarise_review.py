#!/usr/bin/env python3
"""REVIEW SPIKE: condense the review's result files into one summary for the
report (spikes/runtimes/results/review/summary.json).

Speed: for each machine, build and thread count,
* `total`: the sum over pages of each page's median run (as in version 1);
* `run_totals`: the total of each repeat on its own (repeat i of every page),
  which are observed numbers, unlike a sum of per-page minima;
* `spread`: (slowest run total - fastest run total) / median run total.
Ratios between builds come with a 95% bootstrap interval over pages (10,000
resamples, fixed seed), so a ranking says how sure it is.

Setup against steady state: page time and end-to-end process time per page,
from a cold process and from one that read another page first.

Usage: summarise_review.py [RESULTS_DIR]
"""
import json
import random
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
RES = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "results" / "review"

SPEED = {
    "Mac M3 Pro": "mac-m1.json",
    "Linux x86-64": "ci-ubuntu-24.04/bench.json",
    "Linux ARM64": "ci-ubuntu-24.04-arm/bench.json",
}
WARM = {
    "Mac M3 Pro": "mac-m2.json",
    "Linux x86-64": "ci-ubuntu-24.04/warm.json",
    "Linux ARM64": "ci-ubuntu-24.04-arm/warm.json",
}
# Pairs whose ratio gets a bootstrap interval: (machine, threads, slower, faster).
RATIOS = [
    ("Linux x86-64", "1", "rten", "ort"),
    ("Linux x86-64", "1", "tract", "ort"),
    ("Linux x86-64", "1", "tract", "rten"),
    ("Linux x86-64", "1", "ort-lines", "ort"),
    ("Linux ARM64", "1", "rten", "ort"),
    ("Linux ARM64", "2", "rten", "ort"),
    ("Linux ARM64", "2", "ort-lines", "ort"),
    ("Mac M3 Pro", "4", "rten", "ort-official"),
    ("Mac M3 Pro", "4", "ort-official-lines", "ort-official"),
    ("Mac M3 Pro", "4", "rten-lines", "rten"),
    ("Mac M3 Pro", "4", "ort-lines", "rten"),
    ("Mac M3 Pro", "4", "tract", "tract-lines"),
    ("Mac M3 Pro", "1", "ort-official", "rten"),
]


def load(name):
    p = RES / name
    return json.loads(p.read_text()) if p.exists() else None


def pages_ok(d, lib, t):
    return {k: v for k, v in d["runtimes"][lib]["threads"][t].items() if not v.get("failed")}


def speed(d):
    out = {}
    for lib, r in d["runtimes"].items():
        out[lib] = {}
        for t in r["threads"]:
            pg = pages_ok(d, lib, t)
            if not pg:
                out[lib][t] = None
                continue
            n = min(len(v.get("runs") or [v]) for v in pg.values())
            run_totals = [sum((v.get("runs") or [v])[i]["page_ms"] for v in pg.values()) / 1000 for i in range(n)]
            med = statistics.median(run_totals)
            out[lib][t] = {
                "pages": len(pg),
                "runs": n,
                "total": sum(v["page_ms"] for v in pg.values()) / 1000,
                "wall": sum(v.get("wall_s") or 0 for v in pg.values()),
                "load": sum(v.get("load_ms") or 0 for v in pg.values()) / 1000,
                "run_totals": run_totals,
                "spread": (max(run_totals) - min(run_totals)) / med if med else None,
                "rss_gib": max(v["rss"] for v in pg.values()) / 2**30,
                "heap_gib": (max(v["heap"] for v in pg.values() if v.get("heap")) / 2**30)
                if any(v.get("heap") for v in pg.values()) else None,
                "deterministic": r.get("deterministic_across_threads"),
            }
    return out


def ratio(d, t, slow, fast, rng, n=10000):
    a, b = pages_ok(d, slow, t), pages_ok(d, fast, t)
    keys = sorted(set(a) & set(b))
    point = sum(a[k]["page_ms"] for k in keys) / sum(b[k]["page_ms"] for k in keys)
    samples = []
    for _ in range(n):
        s = [keys[rng.randrange(len(keys))] for _ in keys]
        samples.append(sum(a[k]["page_ms"] for k in s) / sum(b[k]["page_ms"] for k in s))
    samples.sort()
    return {"ratio": point, "ci95": [samples[int(0.025 * n)], samples[int(0.975 * n) - 1]], "pages": len(keys)}


def main():
    rng = random.Random(20261112)
    summary = {"speed": {}, "ratios": [], "warm": {}, "max_spread": None}
    spreads = []
    for machine, f in SPEED.items():
        d = load(f)
        if d is None:
            continue
        summary["speed"][machine] = {"cpu": d.get("cpu"), "repeats": d.get("repeats"), "builds": speed(d)}
        for lib, ts in summary["speed"][machine]["builds"].items():
            spreads += [(v["spread"], machine, lib, t) for t, v in ts.items() if v and v["spread"] is not None]
    if spreads:
        top = max(spreads)
        summary["max_spread"] = {"spread": top[0], "machine": top[1], "build": top[2], "threads": top[3]}
        summary["median_spread"] = statistics.median(s[0] for s in spreads)
    for machine, t, slow, fast in RATIOS:
        d = load(SPEED[machine])
        if d is None or slow not in d["runtimes"] or fast not in d["runtimes"]:
            continue
        summary["ratios"].append({"machine": machine, "threads": t, "slower": slow, "faster": fast,
                                  **ratio(d, t, slow, fast, rng)})
    for machine, f in WARM.items():
        w, c = load(f), load(SPEED[machine])
        if w is None or c is None:
            continue
        summary["warm"][machine] = {}
        for lib in w["runtimes"]:
            for t in w["runtimes"][lib]["threads"]:
                if lib not in c["runtimes"] or t not in c["runtimes"][lib]["threads"]:
                    continue
                wp, cp = pages_ok(w, lib, t), pages_ok(c, lib, t)
                keys = sorted(set(wp) & set(cp))
                summary["warm"][machine].setdefault(lib, {})[t] = {
                    "pages": len(keys),
                    "cold_page": sum(cp[k]["page_ms"] for k in keys) / 1000,
                    "warm_page": sum(wp[k]["page_ms"] for k in keys) / 1000,
                    "cold_wall": sum(cp[k].get("wall_s") or 0 for k in keys),
                    "cold_load": sum(cp[k].get("load_ms") or 0 for k in keys) / 1000,
                }
    (RES / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps({"max_spread": summary["max_spread"], "median_spread": summary.get("median_spread"),
                      "ratios": [(r["machine"], r["threads"], r["slower"], r["faster"], round(r["ratio"], 3),
                                  [round(x, 3) for x in r["ci95"]]) for r in summary["ratios"]],
                      "warm": summary["warm"]}, indent=1))


if __name__ == "__main__":
    main()
