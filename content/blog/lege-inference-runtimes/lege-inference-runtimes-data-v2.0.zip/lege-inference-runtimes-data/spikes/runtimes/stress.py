#!/usr/bin/env python3
"""REVIEW SPIKE: run each binary over arbitrary images (for example full-size
newspaper scans) at several thread counts, once each, and record page time,
end-to-end process time, peak resident memory, peak heap (heap-stats builds),
the number of text lines, and whether the ALTO is byte-identical across
thread counts. There is no ground truth, so no accuracy is reported.

Usage: stress.py --models DIR --out DIR --images A.png,B.png --bin NAME=PATH [...]
       [--threads 1,4] [--env NAME:KEY=VALUE ...] [--label TEXT]
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from bench import HEAP, TIMING, cpu_name, parse_rss, peak_rss_args  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", required=True)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--images", required=True)
    ap.add_argument("--bin", action="append", default=[])
    ap.add_argument("--threads", default="1,4")
    ap.add_argument("--env", action="append", default=[])
    ap.add_argument("--label", default="")
    a = ap.parse_args()
    threads = [int(t) for t in a.threads.split(",")]
    envs = defaultdict(dict)
    for spec in a.env:
        name, kv = spec.split(":", 1)
        k, v = kv.split("=", 1)
        envs[name][k] = v
    bins = dict(b.split("=", 1) for b in a.bin)
    results = {"label": a.label, "cpu": cpu_name(), "envs": envs, "images": {}}
    for image in a.images.split(","):
        image = Path(image)
        row = results["images"].setdefault(image.name, {})
        for t in threads:
            for name, binary in bins.items():  # take turns
                out = a.out / name / f"t{t}"
                out.mkdir(parents=True, exist_ok=True)
                cmd = peak_rss_args() + [binary, "--models", a.models, "--out-dir", str(out),
                                         "--threads", str(t), "--timing", str(image)]
                start = time.monotonic()
                p = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, **envs[name]})
                wall = time.monotonic() - start
                timing = dict((k, float(v)) for k, v in TIMING.findall(p.stderr))
                alto = out / f"{image.stem}.alto.xml"
                txt = out / f"{image.stem}.txt"
                m = HEAP.search(p.stderr)
                r = {
                    "exit": p.returncode,
                    "page_ms": timing.get("page"),
                    "wall_s": wall,
                    "rss": parse_rss(p.stderr),
                    "heap": int(m.group(1)) if m else None,
                    "lines": txt.read_text().count("\n") if p.returncode == 0 else None,
                    "alto_sha": hashlib.sha256(alto.read_bytes()).hexdigest()[:12] if p.returncode == 0 else None,
                }
                row.setdefault(name, {})[str(t)] = r
                print(f"{image.name} {name} t{t}: {r['page_ms']} ms, rss {r['rss']}, heap {r['heap']}, "
                      f"{r['lines']} lines, alto {r['alto_sha']}", flush=True)
        for name in bins:
            shas = {v["alto_sha"] for v in row[name].values()}
            row[name]["same_at_any_thread_count"] = len(shas) == 1
    a.out.mkdir(parents=True, exist_ok=True)
    (a.out / "stress.json").write_text(json.dumps(results, indent=2, default=dict))


if __name__ == "__main__":
    main()
