#!/usr/bin/env python3
"""MODEL SPIKE: character error rate of PP-OCRv5 against PP-OCRv6 on the pages
that have a transcription.

Two kinds of transcription, reported separately:
  * ground truth: the 4 synthetic lines (tests/fixtures/reference/ground-truth),
    exact by construction;
  * drafts: 12 scanned pages (ground-truth-drafts). Not yet reviewed, and made
    by checking Lege's PP-OCRv5 output against a book, so words where v5 and the
    book agreed were not checked one by one. This favours v5.

PP-OCRv5's text is the approved snapshot (tests/fixtures/reference/expected).
PP-OCRv6's text is read from a bench.py output folder (first library, 1 thread,
last run): the libraries read the same text, which bench.py also checks.

Usage: v6_accuracy.py --run NAME=BENCH_DIR [--run ...] --out accuracy.json
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests" / "tools"))
from cer import cer  # noqa: E402

REF = ROOT / "tests" / "fixtures" / "reference"


def transcriptions():
    out = []
    for p in sorted((REF / "ground-truth").glob("*.gt.txt")):
        out.append(("ground truth", p.name.removesuffix(".gt.txt"), p.read_text()))
    for p in sorted((REF / "ground-truth-drafts").glob("*.draft.txt")):
        out.append(("drafts", p.name.removesuffix(".draft.txt"), p.read_text()))
    return out


def find_text(bench: Path, stem: str):
    hits = sorted(bench.glob(f"*/t1/r*/{stem}.txt"))
    return hits[-1].read_text() if hits else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", action="append", default=[])
    ap.add_argument("--out", required=True, type=Path)
    a = ap.parse_args()
    runs = {"PP-OCRv5 mobile": None} | {r.split("=", 1)[0]: Path(r.split("=", 1)[1]) for r in a.run}
    report = {"pages": {}, "summary": {}}
    for kind, stem, truth in transcriptions():
        row = {"kind": kind}
        for name, bench in runs.items():
            text = (REF / "expected" / f"{stem}.txt").read_text() if bench is None else find_text(bench, stem)
            row[name] = None if text is None else cer(truth, text)
        report["pages"][stem] = row
    for kind in ("ground truth", "drafts"):
        rows = [r for r in report["pages"].values() if r["kind"] == kind]
        report["summary"][kind] = {
            name: (sum(r[name] for r in rows) / len(rows)) if rows and all(r[name] is not None for r in rows) else None
            for name in runs
        } | {"pages": len(rows)}
    a.out.write_text(json.dumps(report, indent=2))
    for kind, s in report["summary"].items():
        print(kind, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in s.items()})


if __name__ == "__main__":
    main()
