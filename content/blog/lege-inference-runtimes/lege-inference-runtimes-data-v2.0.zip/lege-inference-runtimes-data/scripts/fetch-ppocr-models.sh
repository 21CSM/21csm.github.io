#!/bin/sh
# Fetch the v0.1 PP-OCR files (ADR-0014) and check their SHA-256s.
# The files are not committed. Point LEGE_MODELS_DIR at the destination
# to run the real-model tests (LEGE_REQUIRE=1 makes them mandatory).
# Each file is downloaded to a temporary name in the destination and moved
# into place only after its SHA-256 matches, so a bad download never leaves
# a file with a model's name behind. Files already present with the pinned
# SHA-256 are kept, so re-running it on a restored cache only verifies.
set -eu
dest=${1:-models}
mkdir -p "$dest"

fetch() {
    url=$1
    name=$2
    sha=$3
    # Already present with the pinned SHA-256 (e.g. restored from a CI cache): keep it.
    if [ -f "$dest/$name" ] && printf '%s  %s\n' "$sha" "$dest/$name" | sha256sum -c --status -; then
        echo "$dest/$name: OK (already present)"
        return 0
    fi
    tmp="$dest/.$name.part"
    rm -f "$tmp"
    if ! curl -fsSL -o "$tmp" "$url"; then
        rm -f "$tmp"
        echo "download failed: $url" >&2
        exit 1
    fi
    if ! printf '%s  %s\n' "$sha" "$tmp" | sha256sum -c --status -; then
        rm -f "$tmp"
        echo "SHA-256 mismatch for $name (expected $sha) from $url" >&2
        exit 1
    fi
    mv -f "$tmp" "$dest/$name"
    echo "$dest/$name: OK"
}

fetch \
    "https://huggingface.co/PaddlePaddle/PP-OCRv5_mobile_det_onnx/resolve/e6f4fa85f00e168c862bc462aebca69eef9b3d3d/inference.onnx" \
    det.onnx \
    a431985659dc921974177a95adcfbb90fd9e51989a5e04d70d0b75f597b6e61d
fetch \
    "https://huggingface.co/PaddlePaddle/PP-LCNet_x0_25_textline_ori_onnx/resolve/aea1f18d97338aaf84b463f90192f2820524a00a/inference.onnx" \
    cls.onnx \
    94a6a0a0425f2b5f08b5df72086f2d72abe40f1d22f6d12d2cd83674f11f2ff3
fetch \
    "https://huggingface.co/PaddlePaddle/latin_PP-OCRv5_mobile_rec_onnx/resolve/89d3a50e2c27e2e7cceeab0e944c25c807d5db4f/inference.onnx" \
    rec.onnx \
    7888113072263cb471b93f66dd5e2ad70548dc526fa1ace760d0d973dd121498
fetch \
    "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/8ee4a20cc64fe2d73adf96110f9c9b1c3b7b85a5/ppocr/utils/dict/ppocrv5_latin_dict.txt" \
    dict.txt \
    ccbcc45730b3fbbd9050c5bc74db6a99067141ef1035e3d14889a84a6b9b1aff

echo "models in $dest"
